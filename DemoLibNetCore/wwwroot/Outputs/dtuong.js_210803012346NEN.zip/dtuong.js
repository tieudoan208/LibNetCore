﻿/// <reference path="Common.js" />
/// <reference path="jquery-1.11.0.js" />
/// <reference name="MicrosoftAjax.js"/>

//QuangNN (30/06/2014)
//Grid - Dat gia tri grid tu bang theo chi so
function Grid_P_DatBangI(gridId, a_cot, b_dt) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var columns = b_grid.columns;

        var data = [];
        for (var i = 0; i < b_dt.length; i++) {
            var newRow = Grid_CreateNewRow(gridId);
            data.push(newRow);

            if (i < b_dt.length) {
                for (var j = 0; j < a_cot.length; j++) {
                    data[i][a_cot[j].toUpperCase()] = b_dt[i][j];
                }
            }
        }

        Grid_CH_DATA(columns, data);
        Grid_AddEmptyRow(gridId, data);

        b_grid.dataSource.data(data);
    }
    catch (err) { alert(err.message); }
}

//QuangNN (16/05/2015) - Khởi tạo lại lưới, thêm các hàng trắng
function Grid_P_MOI(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();

    var pageSize = b_grid.dataSource.pageSize();
    if (pageSize === undefined) {
        pageSize = $("#" + gridId).attr("page_size");
    }

    b_rows = [];
    var newRow = Grid_CreateNewRow(gridId);

    for (var i = 0; i < pageSize; i++) {
        b_rows.push(newRow);
    }

    b_grid.dataSource.data(b_rows);
}

//QuangNN (19/03/2015)
//Edit Cell
function Grid_GetEditControl(gridId, b_hang, b_icot) {
    return $("#" + gridId + " tbody tr:eq(" + b_hang + ") td:eq(" + b_icot + ") input");
}

//QuangNN (13/03/2015)
//Grid - Thêm hàng trắng vào cuối lưới, không kiểm tra cuối lưới có là hàng trắng hay không
function Grid_ChenCuoi(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();

    var newRow = Grid_CreateNewRow(gridId);
    b_rows.push(newRow);
}

//Chọn tất cả các hàng trên lưới
function Grid_SelectAllRow(gridId) {
    try {
        $("#" + gridId + " tbody tr").addClass('k-state-selected');
    }
    catch (ex) { }
}

//Chọn các hàng trên lưới từ hàng range[0] đến range[1]
function Grid_SelectRow(gridId, range) {
    try {
        if (range != null) {
            for (var i = range[0]; i <= range[1]; i++) {
                $("#" + gridId + " tbody tr:eq(" + i + ")").addClass('k-state-selected');
            }
        }
    }
    catch (ex) { }
}
//QuangNN (19/08/2014)
//Convert dữ liệu hiển thị trên lưới (kiểu Money -> kiếu số)
function Grid_CH_DATA_R(columns, data) {
    var a = [], b = [], k = 0;
    for (var i = 0; i < columns.length; i++) {
        if (columns[i].dataType == "Money") {
            a[k] = columns[i].field;
            b[k] = columns[i].so_tp;
            k++;
        }
    }
    $.each(data, function (v, t) {
        $.each(t, function (u, x) {
            for (var p = 0; p < a.length; p++) {
                if (u == a[p] && (x != "" && x != null)) {
                    data[v][u] = CSO_SO(x, b[p]);
                }
            }
        })
    })
}

//QuangNN (08/09/2014)
//Grid - Lọc các hàng dữ liệu theo điều kiện khác
function Grid_FilterDataNE(gridId, a_ten, a_gtri) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var result = [];
        var count = 0;

        for (var i = 0; i < b_rows.length; i++) {
            var b_row = b_rows[i];
            var flag = true;

            for (var j = 0; j < a_ten.length; j++) {
                var field = a_ten[j].toUpperCase();

                if (b_row[field] == null || b_row[field] == a_gtri[j]) {
                    flag = false;
                    break;
                }
            }

            if (flag) {
                result[count] = b_row;
                count++;
            }
        }

        return result;
    }
    catch (ex) { return null; }
}

function Grid_GetColumns(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        return b_grid.columns;
    }
    catch (ex) { return null; }
}

function isNumber(obj) {
    return !isNaN(parseFloat(obj));
}

//QuangNN (15/05/2014)
//Thêm các dòng dữ liệu liệu trắng cho đủ số row
function parseGridData(b_kq, minRowNumber, fieldNames) {
    minRowNumber = typeof minRowNumber !== 'undefined' ? minRowNumber : 0;

    var data = $.parseJSON(b_kq);
    var length = data.length;

    if (minRowNumber > 0 && minRowNumber > length) {
        if (typeof fieldNames !== 'undefined') {
            for (var i = 0; i < minRowNumber - length; i++) {
                var obj = {};

                for (var j = 0; j < fieldNames.length; j++) {
                    obj[fieldNames[j].toUpperCase()] = null
                }

                data.push(obj);
            }
        }
    }

    return data;
}

//Kiểm tra cell xem có bị disable không
function isDisabledCell(gridId, b_hang, b_cot) {
    try {
        var disabledCells_json = $("#" + gridId).attr("DisabledCells");

        if (disabledCells_json !== undefined && disabledCells_json !== '') {
            var disabledCells = $.parseJSON(disabledCells_json);

            for (var i = 0; i < disabledCells.length; i++) {
                if (disabledCells[i].ROW == b_hang && disabledCells[i].FIELD_NAME == b_cot) {
                    return true;
                }
            }
        }

        return false;
    }
    catch (ex) { return false; }
}

//Đặt Enabled/Disabled cho cell
function Grid_P_SetDisabledCells(gridId, b_hang, a_cot, b_dat) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        var disabledCells = [];
        var disabledCells_json = $("#" + gridId).attr("DisabledCells")

        if (disabledCells_json !== undefined && disabledCells_json !== '') {
            disabledCells = $.parseJSON(disabledCells_json);
        }

        for (var i = 0; i < a_cot.length; i++) {
            var existed = false;

            for (var j = 0; j < disabledCells.length; j++) {
                if (disabledCells[j].ROW == b_hang && disabledCells[j].FIELD_NAME == a_cot[i]) {
                    if (b_dat) {
                        existed = true;
                        break;
                    }
                    else {
                        disabledCells.splice(j, 1);
                        break;
                    }
                }
            }

            if (!existed && b_dat) {
                var newRow = new Object();
                newRow.ROW = b_hang;
                newRow.FIELD_NAME = a_cot[i];

                disabledCells.push(newRow);
            }
        }

        $("#" + gridId).attr("DisabledCells", JSON.stringify(disabledCells));
    }
    catch (ex) { }
}

function Grid_Fdt_CotGtriLHT(gridId, a_cot) {
    try {
        var a_loc = [], b_kt = 0;
        for (var i = 0; i < a_cot.length; i++) {
            if (a_cot[i] == a_cot[i].toUpperCase()) { a_loc[b_kt] = a_cot[i]; b_kt++; }
        }
        return Grid_Fdt_CotGtriLocHT(gridId, a_cot, a_loc)
    }
    catch (ex) { return [a_cot, null]; }
}

function Grid_Fdt_CotGtriLocHT(gridId, a_cot, a_loc) {
    try {
        var a_gtri = Fdt_Grid_LayGtriN(gridId, a_cot);

        if (a_gtri == null || a_loc == null || a_loc.length == 0) return [a_cot, a_gtri];

        var b_cot = 0, b_kt = 0, b_log = true, a_moi = [];

        for (var i = 0; i < a_gtri.length; i++) {
            b_log = false;

            for (var j = 0; j < a_loc.length; j++) {
                b_cot = Fi_vtri_mang(a_cot, a_loc[j]);

                var value = (a_gtri[i][b_cot] == null && (a_gtri[i][b_cot]) == undefined) ? "" : a_gtri[i][b_cot];

                if (value != "" && value != 0) {
                    b_log = true;
                }
            }

            if (b_log) { a_moi[b_kt] = a_gtri[i]; b_kt++; }
        }
        return (a_moi.length == 0) ? [a_cot, null] : [a_cot, a_moi];
    }
    catch (ex) { return [a_cot, null]; }
}

//QuangNN (08/09/2014)
//Grid - Lọc các hàng dữ liệu theo điều kiện bằng
function Grid_FilterData(gridId, a_ten, a_gtri) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var result = [];
        var count = 0;

        for (var i = 0; i < b_rows.length; i++) {
            var b_row = b_rows[i];
            var flag = true;

            for (var j = 0; j < a_ten.length; j++) {
                var field = a_ten[j].toUpperCase();

                if (b_row[field] == null || b_row[field] != a_gtri[j]) {
                    flag = false;
                    break;
                }
            }

            if (flag) {
                result[count] = b_row;
                count++;
            }
        }

        return result;
    }
    catch (ex) { return null; }
}

//Ngay - Key press
function thang_an(b_ctr, event) {
    try {
        var b_key = sukien_Fn_keyPress(event);
        if (b_key <= 0) return;
        if (event.ctrlKey) return;
        sukien_P_keyPress(event, 0);
        var b_s = String.fromCharCode(b_key), b_cu = b_ctr.value;
        if ("0123456789".indexOf(b_s) < 0) { Attribute_P_DAT(b_ctr, "Tchange", "C"); event.preventDefault ? event.preventDefault() : event.returnValue = false; return false; }
        var b_vtri = contro_vtri(b_ctr), b_moi, b_cuoi;
        if (b_vtri < b_cu.length) b_cuoi = "K"; else b_cuoi = "C";
        b_cu = b_cu.substr(0, b_vtri) + b_s + b_cu.substr(b_vtri + 1);
        b_vtri += 1;
        b_moi = CH_CTH(b_cu);
        if (b_moi.substr(b_vtri, 1) == "/") b_vtri += 1;
        b_ctr.value = b_moi;
        contro_dat(b_ctr, b_vtri); Attribute_P_DAT(b_ctr, "Tchange", "C");
        event.preventDefault ? event.preventDefault() : event.returnValue = false;
        return false;
    }
    catch (ex) { }
}
function CH_CTH(e) {
    try {
        if (e == "") return "";
        var t = "", n, r;
        for (r = 0; r < e.length; r++) {
            n = e.substr(r, 1);
            if ("0123456789".indexOf(n) >= 0) t = t + n
        }
        if (t == "") return "";
        t = t + "       ";
        t = t.substr(0, 2) + "/" + t.substr(2, 4);
        return t
    }
    catch (i) {
        return e
    }
}
//QuangNN (16/05/2014)
//Array - Kiem tra hang trang cua mang
function Array_Fb_HangTrang(data, b_hang, a_cot) {
    try {
        if (b_hang >= data.length) return true;

        for (var i = 0; i < a_cot.length; i++) {
            if (data[b_hang][a_cot[i].toUpperCase()] != null) {
                return false;
            }
        }

        return true;
    }
    catch (ex) { return true; }
}

//QuangNN (25/08/2014) - 
//Grid - Thêm các hàng trắng cho đủ trang
function Grid_AddEmptyRow(gridId, data) {
    var a_cot = Grid_Fas_TenCot(gridId);
    var length = data.length;
    while (length > 0 && Array_Fb_HangTrang(data, length - 1, a_cot)) length--;

    var b_grid = $("#" + gridId).data("kendoGrid");
    var recordNumber;

    var pageSize = b_grid.dataSource.pageSize();
    if (pageSize === undefined) {
        var page_size = $("#" + gridId).attr("page_size");

        recordNumber = Math.max(length, page_size);
    }
    else {
        recordNumber = Fi_RowNumber(length, pageSize);
    }

    if (recordNumber >= data.length) {
        var count = recordNumber - data.length;

        for (var i = 0; i < count; i++) {
            var newRow = Grid_CreateNewRow(gridId);
            data.push(newRow);
        }
    } else {
        var count = data.length - recordNumber;
        data.splice(length, count);
    }
}

//QuangNN (29/05/2014);
//Grid - Cat hang da chon
function Grid_cutRowSelect(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        b_grid.select().each(function () {
            b_grid.removeRow($(this));
        });

        var b_rows = b_grid.dataSource.data();
        Grid_AddEmptyRow(gridId, b_rows);
    }
    catch (ex) { }
}

//QuangNN (13/08/2014)
//Grid - Cat hang theo dieu kien tren luoi
function Grid_cutRowDK(gridId, b_cot, b_gtri) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        var i = 0;
        while (i < b_rows.length) {
            if (b_rows[i][b_cot] == b_gtri) {
                //Xoa hàng duoc danh dau
                b_rows.splice(i, 1);
            }
            else i++;
        }

        Grid_AddEmptyRow(gridId, b_rows);

        var pageNumber = b_grid.dataSource.page();
        if (pageNumber !== undefined) {
            var totalPages = b_grid.dataSource.totalPages();

            if (pageNumber > totalPages) {
                b_grid.dataSource.page(totalPages);
            }
        }
    }
    catch (err) { }
}

//QuangNN (22/05/2014)
//Grid - Dat gia tri grid tu bang
function Grid_P_DatBang(gridId, a_cot, b_dt) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var columns = b_grid.columns;

        var data = [];
        for (var i = 0; i < b_dt.length; i++) {
            var newRow = Grid_CreateNewRow(gridId);
            data.push(newRow);

            if (i < b_dt.length) {
                for (var j = 0; j < a_cot.length; j++) {
                    data[i][a_cot[j].toUpperCase()] = b_dt[i][a_cot[j].toUpperCase()];
                }
            }
        }

        Grid_CH_DATA(columns, data);
        Grid_AddEmptyRow(gridId, data);

        b_grid.dataSource.data(data);
    }
    catch (err) { alert(err.message); }
}

//QuangNN (22/05/2014)
//Grid - Dat gia tri grid tu chuoi
function Grid_P_DatBangCH(gridId, b_ch) {
    try {
        if (b_ch != "" && b_ch != "[]") {
            var b_grid = $("#" + gridId).data("kendoGrid");
            var columns = b_grid.columns;
            var a_cot = Grid_Fas_TenCot(gridId);
            var data = [];

            var pageSize = b_grid.dataSource.pageSize();
            if (pageSize === undefined) {
                var page_size = $("#" + gridId).attr("page_size");

                data = parseGridData(b_ch, page_size, a_cot);
            }
            else {
                var maxRowNumber = Grid_Fi_MaxRowNumberPT(gridId, b_ch);

                data = parseGridData(b_ch, maxRowNumber, a_cot);
            }

            Grid_CH_DATA(columns, data);

            b_grid.dataSource.data(data);
        }
        else Grid_DatTrangCa(gridId);
    }
    catch (err) { }
}

//QuangNN (22/05/2014)
//Grid - Dat trang ca trang
function Grid_DatTrangCa(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var page_size = $("#" + gridId).attr("page_size");
        var a_cot = Grid_Fas_TenCot(gridId);
        var data = parseGridData('[]', page_size, a_cot);

        b_grid.dataSource.data(data);
    }
    catch (ex) { }
}

//QuangNN (09/06/2014) 
//Grid - Them hang vao grid tu bang
function P_Grid_ThemHang(gridId, b_dt, b_ss) {
    if (b_dt == null || b_dt.length == 0) return;

    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();
    var a_cot = Grid_Fas_TenCot(gridId);

    if (b_rows.length > 0 && !Grid_Fb_HangTrang(gridId, 0)) {
        var a_log = [];

        if (b_ss != "") {
            var a_ss = b_ss.split(',');

            for (var j = 0; j < a_cot.length; j++) {
                a_log[j] = false;

                for (var i = 0; i < a_ss.length; i++) {
                    if (a_cot[j].toUpperCase() == a_ss[i].toUpperCase()) { a_log[j] = true; break; }
                }
            }
        }

        //xoa cac dong trang o cuoi
        var b_hang_c = b_rows.length;
        while (b_hang_c > 0 && Grid_Fb_HangTrang(gridId, b_hang_c - 1)) b_hang_c--;
        if (b_hang_c != b_rows.length) b_rows.splice(b_hang_c, b_rows.length - b_hang_c);

        var b_hang_m = b_hang_c;
        var b_log = true;
        var b_dung = true;

        if (b_ss != "") {
            for (var i = 0; i < b_dt.length; i++) {
                b_log = true;

                for (var j = 0; j < b_hang_c; j++) {
                    b_dung = true;

                    for (var k = 0; k < a_cot.length; k++) {
                        if (a_log[k]) {
                            if (b_dt[i][a_cot[k]] == null || b_rows[j][a_cot[k]] == null) {
                                b_dung = false;
                                break;
                            }
                            else if (b_dt[i][a_cot[k]] != b_rows[j][a_cot[k]]) {
                                b_dung = false;
                                break;
                            }
                        }
                    }

                    if (b_dung) { b_log = false; break; }
                }

                if (b_log) {
                    b_rows.push(b_dt[i]);
                    b_hang_m++;
                }
            }
        }
        else {
            for (var i = 0; i < b_dt.length; i++) {
                b_rows.push(b_dt[i]);
                b_hang_m++;
            }
        }

        Grid_P_DatBang(gridId, a_cot, b_rows);
        Grid_SelectRow(gridId, [b_hang_c, b_hang_m - 1]);
    }
    else {
        Grid_P_DatBang(gridId, a_cot, b_dt);
        Grid_SelectRow(gridId, [0, b_dt.length - 1]);
    }
}

//QuangNN (19/08/2014)
//Convert dữ liệu hiển thị trên lưới (kiếu số -> kiểu Money)
function Grid_CH_DATA(columns, data) {
    var a = [], b = [], k = 0;
    for (var i = 0; i < columns.length; i++) {
        if (columns[i].dataType == "Money") {
            a[k] = columns[i].field;
            b[k] = columns[i].so_tp;
            k++;
        }
    }
    $.each(data, function (v, t) {
        $.each(t, function (u, x) {
            for (var p = 0; p < a.length; p++) {
                if (u == a[p] && (x != "" && x != null)) {
                    data[v][u] = CH_CSO(x.toString(), b[p]);
                }
            }
        })
    })
}

//QuangNN (23/07/2014)
//Đặt giá trị của một cột
function Grid_P_DatGtriCot(gridId, a_cot, a_gtri) {
    try {
        for (var j = 0; j < a_cot.length; j++) a_cot[j] = a_cot[j].toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        for (var i = 0; i < b_rows.length; i++) {
            for (var j = 0; j < a_cot.length; j++) {
                if (!Grid_Fb_HangTrang(gridId, i)) {
                    b_rows[i][a_cot[j]] = a_gtri[j];
                }
            }
        }

        b_grid.refresh();
    }
    catch (ex) { }
}

//QuangNN (30/05/2014) - OK
//Convert chuoi thanh bang
function Fdt_ChBang(b_chuoi) {
    try {
        if (C_NVL(b_chuoi) == "") return null;

        return $.parseJSON(b_chuoi);
    }
    catch (ex) { return null; }
}

//QuangNN (13/08/2014)
//Tính số hàng lớn nhất trên lưới có phân trang (bao gồm số hàng dữ liệu + số hàng trắng cho đầy trang)
function Grid_Fi_MaxRowNumberPT(gridId, b_ch) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var data = $.parseJSON(b_ch);
        var length = data.length;

        var page_size = b_grid.dataSource.pageSize();

        if (page_size === undefined) return 0;

        return Fi_RowNumber(length, page_size);
    }
    catch (err) { return 0; }
}

//QuangNN (29/05/2014) - Grid_DatActiveRow
//Grid - Cat hang Active
function Grid_cutRowAct(gridId) {
    try {
        var b_hang = Grid_Fi_HangActive(gridId);
        if (b_hang < 0) return;

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_tiep = (b_hang == b_rows.length - 1 || Grid_Fb_HangTrang(gridId, b_hang + 1)) ? b_hang - 1 : b_hang;

        //Xoa hàng active
        b_rows.splice(b_hang, 1);

        Grid_AddEmptyRow(gridId, b_rows);

        if (b_tiep >= 0) {
            var page_size = b_grid.dataSource.pageSize();

            if (page_size === undefined) {
                Grid_DatActiveRow(gridId, Grid_Fi_GridRowIndex(gridId, b_tiep));
            }
            else {
                Grid_To_PageH(gridId, b_tiep, 0);
            }
        }
    }
    catch (err) { }
}

//QuangNN (30/07/2014)
//Grid - Kiem tra ca trang cuoi cung cua luoi co phai la trang trang khong (trong truong hop luoi chi co 1 trang thi ko kiem tra)
function Grid_Fb_PageCuoiTrang(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var page_size = b_grid.dataSource.pageSize();

        if (page_size === undefined || b_rows.length == page_size) return;

        for (var i = b_rows.length - 1; i >= b_rows.length - page_size; i--)
            if (!Grid_Fb_HangTrang(gridId, i)) return false;

        return true;
    }
    catch (ex) { return true; }
}

//QuangNN (30/07/2014)
//Grid - Xoa trang cuoi (trong truong hop luoi chi co 1 trang thi ko xoa)
function Grid_removePageCuoi(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var page_size = b_grid.dataSource.pageSize();

        if (page_size === undefined || b_rows.length == page_size) return;

        b_rows.splice(b_rows.length - page_size, page_size);
    }
    catch (err) { }
}

//QuangNN (19/05/2014)
//Grid - Dat gia tri 1 cot
function Grid_P_DatGtri(gridId, b_hang, b_cot, b_gtri) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        if (b_hang >= 0 && b_hang < b_rows.length && b_rows[b_hang].hasOwnProperty(b_cot)) {
            b_rows[b_hang][b_cot] = b_gtri;
        }

        b_grid.refresh();
    }
    catch (ex) { }
}

//QuangNN (09/06/2014)
//Grid - Dat gia tri tu bang vao Grid theo cot key a_ten (co thi thay gia gtri, chua co thi them)
function Grid_P_DatGtriT(gridId, b_ten, a_dt) {
    b_ten = b_ten.toUpperCase();

    var a_ten = b_ten.split(',');
    var a_cot = Grid_Fas_TenCot(gridId);
    var a_gtri = Faobj_gtri_mang(a_dt[0], a_dt[1], a_cot);

    a_gtri = kytu_locUnicode(a_gtri);

    var a_ma = Faobj_gtri_mang(a_cot, a_gtri, a_ten);
    var b_hang = Grid_Fi_TimHangXep(gridId, a_ten, a_ma);
    var b_soDong = Grid_Fi_soDong(gridId);

    if (b_hang < 0 || b_hang != Grid_Fi_TimHangN(gridId, a_ten, a_ma)) {
        b_hang++;
        Grid_ChenTai(gridId, b_hang);
    }

    Grid_P_DatGtriN(gridId, b_hang, a_cot, a_gtri);

    //Them hoac xoa hang trang cho du trang
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();
    Grid_AddEmptyRow(gridId, b_rows);

    Grid_To_PageH(gridId, b_hang, 0);
}

//QuangNN (09/06/2014)
//Grid - Dat gia tri tu bang vao Grid co phan trang theo cot key a_ten (co thi thay gia gtri, chua co thi them)
function Grid_P_DatGtriPT(gridId, b_ten, a_dt) {
    Grid_P_DatGtriT(gridId, b_ten, a_dt);
}

//QuangNN (30/07/2014)
//Grid - Them mot trang trang vao luoi (them so ban ghi bang pageSize)
function Grid_ThemTrangCuoi(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var page_size = b_grid.dataSource.pageSize();

    if (page_size !== undefined) {
        Grid_ThemCuoiC(gridId, page_size);
    }
}

//QuangNN (30/07/2014)
//Grid - Them mot so ban ghi trang vao cuoi trang
function Grid_ThemCuoiC(gridId, b_count) {
    for (var i = 0; i < b_count; i++) Grid_ThemCuoi(gridId);
}

//QuangNN (29/07/2014)
//Grid - Xoa hang cuoi cung
function Grid_removeRowCuoi(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_hang = b_rows.length - 1;

        Grid_removeRow(gridId, b_hang);
    }
    catch (err) { }
}

//QuangNN (29/07/2014)
//Grid - Xoa hang
function Grid_removeRow(gridId, b_hang) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        if (b_hang < 0 || b_hang >= b_rows.length) return;

        b_rows.splice(b_hang, 1);
    }
    catch (err) { }
}

//QuangNN (10/06/2014) - Cần sửa lại
// Liet ke ket qua
function Grid_P_LKE(gridId, b_tu_m, b_kq) {
    try {
        var b_cot = Grid_Fs_cotTt(gridId),
            b_vtri = Grid_Fn_scrollVtri(gridId), b_dat = "K", b_hang = -1;
        var b_tu_c = Grid_Fobj_LayGtri(gridId, 0, b_cot), b_sott = Grid_Fobj_LayGtri(gridId, 0, b_cot);
        if (b_sott != null && b_sott < 0) b_dat = (b_sott < -1) ? "C" : "D";
        Grid_P_DatBangCH(gridId, b_kq);
        var b_cao = Grid_Fn_scrollMax(gridId);
        if (b_dat == "D") b_vtri = 0;
        else if (b_dat == "C") b_vtri = b_cao;
        else {
            if (b_tu_c == null) b_tu_c = 1;
            if (b_tu_c != b_tu_m) b_vtri += Grid_Fn_scrollCao(gridId, b_tu_c - b_tu_m);
            if (b_vtri < 0) b_vtri = 0;
            else if (b_vtri > b_cao) b_vtri = b_cao;
            b_sott = Grid_Fobj_LayGtri_Act(gridId, b_cot);
            if (b_sott != null && b_sott >= 0) b_hang = Grid_Fi_TimHang(gridId, b_cot, b_sott);
        }
        Grid_P_scrollDat(gridId, b_vtri);
        if (b_hang < 0) Grid_ThoiActive(gridId);
        else Grid_ChiActiveRow(gridId, b_hang);
    }
    catch (err) { }
}

//QuangNN (10/06/2014) - Cần sửa lại
function Grid_Faobj_VungCh(gridId, b_soTrang) {
    try {
        var b_soDong = Grid_Fi_soDong(gridId),
            b_TrangKt = Grid_Fi_TrangKt(gridId),
            b_cot = Grid_Fs_cotTt(gridId);

        if (b_TrangKt == 0 || b_cot == "") return null;
        var b_tu = 1, b_den = b_TrangKt, b_dongTo = b_TrangKt * b_soTrang, b_vtri = Grid_Fn_scrollVtri(gridId);
        var b_dongTh = ROUNDN(b_TrangKt * (b_soTrang + 1) / 2, 0);
        if (!Grid_Fb_HangTrang(gridId, 0)) {
            var b_sott = Grid_Fobj_LayGtri(gridId, 0, b_cot);
            if (b_sott != null && b_sott < 0) {
                if (b_sott < -1) { b_den = 1000000; b_tu = 2 * b_TrangKt - 2; }
                else b_den = b_tu + 2 * b_TrangKt - 1;
            }
            else {
                var b_chuyen = Grid_Fs_Vungktra(gridId);
                if (b_chuyen == "K") return null;
                b_tu = Grid_Fobj_LayGtri(gridId, 0, b_cot);
                if (b_tu == null || b_tu == 0) b_tu = 1;
                if (b_chuyen == "L") {
                    b_tu -= b_dongTh;
                    if (b_tu < 1) b_tu = 1;
                }
                else if (b_soDong >= b_dongTo) b_tu += b_dongTh;
                if (b_tu == 1 && b_soDong == b_TrangKt) b_den = b_tu + 2 * b_TrangKt - 1;
                else b_den = b_tu + b_dongTo - 1;
            }
        }
        return [b_tu, b_den];
    }
    catch (ex) { return null; }
}

//QuangNN (10/06/2014) - Cần sửa lại
// Kiem tra chuyen vung
function Grid_Fs_Vungktra(gridId) {
    try {
        var b_soDong = Grid_Fi_soDong(gridId), b_TrangKt = Grid_Fi_TrangKt(gridId), b_cot = Grid_Fs_cotTt(gridId);
        if (b_TrangKt == 0 || b_cot == "") return "K";
        if (b_soDong == 0) return "X";
        var b_vtri = Grid_Fn_scrollVtri(gridId), b_vdau = Grid_Fn_scrollCao(gridId, b_TrangKt - 1), b_sott = 0;
        var b_vcuoi = Grid_Fn_scrollMax(gridId) - Grid_Fn_scrollCao(gridId, 1.5 * b_TrangKt);
        if (b_vtri <= b_vdau) {
            b_sott = Grid_Fobj_LayGtri(gridId, 0, b_cot);
            if (b_sott != null && b_sott > b_TrangKt) return "L";
        }
        if (b_vtri >= b_vcuoi) {
            b_sott = Grid_Fobj_LayGtri(gridId, b_soDong - 1, b_cot);
            if (b_sott != null && b_sott != 0) return "X";
        }
        return "K";
    }
    catch (ex) { return "K"; }
}

//QuangNN (22/07/2014)
//Grid - set Tooltip theo gia tri cot
function Grid_SetTooltip(gridId, b_cot) {
    b_cot = b_cot.toUpperCase();
    var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

    $("#" + gridId).kendoTooltip({
        filter: "td:nth-child(" + (b_icot + 1) + ")",
        //position: "right", 
        content: function (e) {
            var dataItem = $("#" + gridId).data("kendoGrid").dataItem(e.target.closest("tr"));
            var content = dataItem[b_cot];
            return content
        }
    }).data("kendoTooltip");
}

//QuangNN (22/07/2014)
//Grid - set Tooltip theo b_value 
function Grid_SetTooltipValue(gridId, b_cot, b_value) {
    b_cot = b_cot.toUpperCase();
    var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

    $("#" + gridId).kendoTooltip({
        filter: "td:nth-child(" + (b_icot + 1) + ")",
        //position: "right", 
        content: function (e) {
            var content = b_value;
            return content
        }
    }).data("kendoTooltip");
}

//QuangNN (22/07/2014)
//Grid - Dem hang thoa man dieu kien don
function Grid_Fi_DemHang(gridId, b_cot, b_gtri) {
    return Grid_Fi_DemHangD(gridId, b_cot, b_gtri, "==");
}



//QuangNN (22/07/2014)
//Grid - Dem hang thoa man dieu kien mang
function Grid_Fi_DemHangN(gridId, a_cot, a_gtri) {
    var a_dk = [];

    for (var i = 0; i < a_cot.length; i++) a_dk[i] = "==";

    return Grid_Fi_DemHangND(gridId, a_cot, a_gtri, a_dk);
}

//QuangNN (09/07/2014) - Grid_DatActiveRow
//Nhảy tới trang trước
function Grid_To_Previous_Page(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var page_number = b_grid.dataSource.page();

    if (page_number !== undefined && page_number > 1) {
        b_grid.dataSource.page(page_number - 1);

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        Grid_DatActiveRow(gridId, b_grid.ROW_SELECTED_INDEX);
        Grid_EditCell(gridId, b_grid.ROW_SELECTED_INDEX, b_grid.COL_SELECTED_INDEX);
    }
}

//QuangNN (09/07/2014) - Grid_DatActiveRow
//Nhảy tới trang sau
function Grid_To_Next_Page(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();
    var page_number = b_grid.dataSource.page();
    var page_size = b_grid.dataSource.pageSize();

    if (page_number !== undefined && page_size !== undefined) {

        var max_page_number = Math.floor(b_rows.length / page_size) + 1;

        if (page_number < max_page_number) {
            b_grid.dataSource.page(page_number + 1);

            if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

            Grid_DatActiveRow(gridId, b_grid.ROW_SELECTED_INDEX);
            Grid_EditCell(gridId, b_grid.ROW_SELECTED_INDEX, b_grid.COL_SELECTED_INDEX);
        }
    }
}

//QuangNN (09/07/2014) - Grid_DatActiveRow
//Nhảy tới trang đầu
function Grid_To_First_Page(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    b_grid.dataSource.page(1);

    if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

    Grid_DatActiveRow(gridId, b_grid.ROW_SELECTED_INDEX);
    Grid_EditCell(gridId, b_grid.ROW_SELECTED_INDEX, b_grid.COL_SELECTED_INDEX);
}

//QuangNN (09/07/2014) - Grid_DatActiveRow
//Nhảy tới trang cuối
function Grid_To_Last_Page(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();
    var page_size = b_grid.dataSource.pageSize();

    if (page_size !== undefined) {
        var max_page_number = Math.floor(b_rows.length / page_size) + 1;

        b_grid.dataSource.page(max_page_number);

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        Grid_DatActiveRow(gridId, b_grid.ROW_SELECTED_INDEX);
        Grid_EditCell(gridId, b_grid.ROW_SELECTED_INDEX, b_grid.COL_SELECTED_INDEX);
    }
}

//QuangNN (09/07/2014)
//Nhảy tới trang có hàng chứa Cell ở b_cot có giá trị b_gtri
function Grid_To_Page(gridId, b_cot, b_gtri) {
    b_cot = b_cot.toUpperCase();

    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();
    var b_hang = -1;

    for (var i = 0; i < b_rows.length; i++) {
        if (b_rows[i][b_cot] == b_gtri) {
            b_hang = i;
            break;
        }
    }

    if (b_hang > -1) {
        var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

        Grid_To_PageH(gridId, b_hang, b_icot);
    }
}
//QuangNN (16/07/2014)
//Nhảy tới trang có hàng chứa Cell ở các cột a_cot có giá trị a_gtri
function Grid_To_PageN(gridId, a_cot, a_gtri) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_hang = -1;

        for (var i = 0; i < b_rows.length; i++) {
            var flag = true;

            for (var j = 0; j < a_cot.length; j++) {
                if (b_rows[i][a_cot[j].toUpperCase()] != a_gtri[j]) {
                    flag = false;
                    break;
                }
            }

            if (flag) {
                b_hang = i;
                break;
            }
        }

        if (b_hang > -1) {
            var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

            Grid_To_PageH(gridId, b_hang, b_icot);
        }
    }
    catch (ex) { }
}
//QuangNN (09/07/2014) - Grid_DatActiveRow
//Nhảy tới trang có hàng b_hang
function Grid_To_PageH(gridId, b_hang, b_icot) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var pageSize = b_grid.dataSource.pageSize();

    if (pageSize !== undefined) {
        var page_number = Math.floor(b_hang / pageSize) + 1;
        var row_index = b_hang % pageSize;

        b_grid.dataSource.page(page_number);
        Grid_DatActiveRow(gridId, row_index);
        Grid_EditCell(gridId, row_index, b_icot);
    }
}


//QuangNN (06/08/2014)
//Nhảy tới trang có hàng b_hang nhung khong dat active row
function Grid_ChiHienRow(gridId, b_hang) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var page_size = b_grid.dataSource.pageSize();

    if (page_size !== undefined) {
        var page_number = Math.floor(b_hang / page_size) + 1;
        var row_index = b_hang % page_size;

        b_grid.dataSource.page(page_number);
    }
}

//QuangNN (10/06/2014) - Grid_DatActiveRow
//Dat chon cho cac hang co hang truoc da chon va co gia tri tai cot b_ten bang hang truoc
function Grid_ThemChonGtri(gridId, b_ten) {
    b_ten = b_ten.toUpperCase();

    var b_icot = Grid_Fi_TtuCot(gridId, b_ten);
    if (b_icot < 0) return;

    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();
    var dataRows = b_grid.items();
    var b_row, b_ttrang_m, b_gtri_m, b_ttrang_c, b_gtri_c;
    var a_indexes = [];

    b_grid.select().each(function () {
        var b_hang = dataRows.index($(this));

        a_indexes.push(b_hang);
    });

    for (var i = 0; i < b_rows.length; i++) {
        b_row = b_rows[i];

        b_ttrang_m = (jQuery.inArray(i, a_indexes) != -1);
        b_gtri_m = b_row[b_ten];

        if (i > 0 && !b_ttrang_m && b_ttrang_c && b_gtri_m == b_gtri_c) {
            Grid_DatActiveRow(gridId, Grid_Fi_GridRowIndex(gridId, i));

            b_ttrang_m = true;
        }

        b_ttrang_c = b_ttrang_m;
        b_gtri_c = b_gtri_m;
    }
}

//QuangNN (11/06/2014) - Chú ý Sửa đoạn code dùng hàm này
//Cũ: Grid - Tra Cell dang active
//Mới: Trả về Column index của Cell dang active
//  - Nếu setValue thì dùng hàm Grid_DatCellActiveValue
//  - Nếu getValue thì dùng hàm Grid_Fs_CellActiveValue
function Grid_Fcell_CellActive(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        return b_grid.COL_SELECTED_INDEX;
    }
    catch (ex) { return -1; }
}

//QuangNN (11/06/2014)
//Đặt value của Cell dang active
function Grid_DatCellActiveValue(gridId, value) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;
        var b_rows = b_grid.dataSource.data();
        var b_hang = Grid_Fi_HangActive(gridId);
        var b_fieldName = b_columns[b_grid.COL_SELECTED_INDEX].field;

        b_rows[b_hang][b_fieldName] = value;

        b_grid.refresh();
    }
    catch (ex) { }
}

//QuangNN (11/06/2014)
//Trả về value của Cell dang active
function Grid_Fs_CellActiveValue(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;
        var b_rows = b_grid.dataSource.data();
        var b_hang = Grid_Fi_HangActive(gridId);
        var b_fieldName = b_columns[b_grid.COL_SELECTED_INDEX].field;

        return b_rows[b_hang][b_fieldName];
    }
    catch (ex) { return null; }
}

//QuangNN (09/06/2014)
//setEditable for cell of grid
function Grid_Cell_Editable(gridId, b_hang, b_cot, b_editable) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

        if (b_editable) Grid_EditCell(gridId, b_hang, b_icot);
        else Grid_CloseCell(gridId, b_hang, b_icot);
    }
    catch (ex) { }
}

//QuangNN (10/06/2014)
//Grid - Tra ten cot thu tu
function Grid_Fs_cotTt(gridId) {
    try {
        var b_ctrId = gridId + "_sott";
        var b_ctr = $get(b_ctrId);
        return (b_ctr == null || b_ctr == undefined) ? "" : C_NVL(b_ctr.value);
    }
    catch (ex) { return ""; }
}

//QuangNN (10/06/2014) - OK
//Grid - Cat hang da chon va nhung hang lien do co dung gia tri tai cot b_cot
function Grid_cutRowSelectG(gridId, b_cot) {
    b_cot = b_cot.toUpperCase();

    Grid_ThemChonGtri(gridId, b_cot); Grid_cutRowSelect(gridId);
}

//QuangNN (10/06/2014) - OK
//Grid - Giu lai hang da chon va nhung hang lien do co dung gia tri tai cot b_cot
function Grid_giuRowSelectG(gridId, b_cot) {
    b_cot = b_cot.toUpperCase();

    Grid_ThemChonGtri(gridId, b_cot); Grid_giuRowSelect(gridId);
}

//QuangNN (10/06/2014) - OK
//Grid - Dat ghi chu tu grid
function Grid_DatGchu(gridId, b_kq) {
    var b_gchuId = $get(gridId + "_gchuId");
    if (b_gchuId != null && b_gchuId.value != null) form_P_DatGchu(b_gchuId.value, b_kq);
}

//QuangNN (07/06/2014) - Chú ý sửa cả hàm lấy ghi chú theo hàm này
//Grid - Dat ghi chu cho hang
function Grid_P_GchuRow(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_gchu = "";
        var b_kieu = "";
        var b_chu = "";
        var b_gtri;
        var a_cot = b_cot.split(',');

        for (var i = 0; i < b_rows.length; i++) {
            if (Grid_Fb_HangTrang(gridId, i)) break;

            b_gchu = "";
            for (var j = 0; j < a_cot.length; j++) {
                b_gtri = Grid_Fobj_LayGtri(gridId, i, a_cot[j]);
                b_kieu = Grid_Fs_KieuCot(gridId, a_cot[j]);
                b_nhan = Grid_Fs_NhanCot(gridId, a_cot[j]) + ": ";

                switch (b_kieu) {
                    case "S": b_chu = b_gtri; break;
                    case "N": b_chu = SO_CSO(b_gtri, 5); break;
                    default: b_chu = b_gtri.toString(); break;
                }

                if (j != 0) b_gchu += "\n";
                b_gchu += b_nhan + C_NVL(b_chu);
            }

            b_rows[i].ROW_TITLE = b_gchu;
            //$get(b_grid.Rows.getRow(i).Id).title = b_gchu;
        }
    }
    catch (ex) { }
}

//QuangNN (30/05/2014) - Hàm chưa được test kĩ - Hàm có thể ko cần được sử dụng vì kendo grid có thể tự hiểu định dạng 
//Grid - Convert so lieu tu mang
function Faobj_Grid_ChLoai(gridId, a_cot, a_gtri) {
    try {
        var a_obj = [];

        for (var i = 0; i < a_cot.length; i++) {
            a_obj[i] = a_gtri[i];
        }
        return a_obj;
    }
    catch (ex) { return null; }
}

//QuangNN (30/05/2014) - Chưa test kĩ
//Chèn 1 bảng vào lưới ở vị trí b_hang
function Grid_P_ChenBang(gridId, b_hang, a_cot, b_dt) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_kt = b_dt.length - 1;

        for (var i = b_kt; i >= 0; i--) {
            var a_gtri = b_dt[i];

            var newRow = Grid_CreateNewRow(gridId);
            b_rows.splice(b_hang, 0, newRow);

            Grid_P_DatGtriN(gridId, b_hang, a_cot, a_gtri);
        }
    }
    catch (ex) { }
}

//QuangNN (30/05/2014) - Chưa test kĩ
//Grid - Them bang vào grid
function Grid_P_ThemBang(gridId, a_cot, b_dt) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        var b_them = b_dt.length;
        var b_hang = b_rows.length;
        var b_bd = Grid_Fi_HangTrang(gridId);

        if (b_bd < 0) b_bd = b_hang;
        else b_them = b_dt.length - b_hang + b_bd;

        if (b_them > 0) {
            for (var i = 0; i < b_them; i++) {
                var newRow = Grid_CreateNewRow(gridId);

                b_rows.push(newRow);
            }
        }

        for (var i = 0; i < b_dt.length; i++) {
            var a_gtri = b_dt[i];
            Grid_P_DatGtriN(gridId, b_bd, a_cot, a_gtri);
            b_bd++;
        }

        var page_size = Grid_Fi_TrangKt(gridId);

        if (page_size > b_bd) {
            b_hang = page_size - b_bd;
            for (var i = 0; i < b_hang; i++) {
                var newRow = Grid_CreateNewRow(gridId);

                b_rows.push(newRow);
            }
        }
    }
    catch (ex) { }
}

//QuangNN (30/05/2014) - Chưa test kĩ
//Grid - Them gia tri grid tu chuoi vao bang cu
function Grid_P_ThemBangCH(gridId, b_ch) {
    try {
        if (b_ch != "") {
            var a_cot = Grid_Fas_TenCot(gridId);
            var b_dt_t = Fdt_ChBang(b_ch);
            var b_dt_m = Fdt_Grid_ChLoai(a_cot, b_dt_t);
            Grid_P_ThemBang(gridId, a_cot, b_dt_m);
        }
    }
    catch (ex) { }
}


//QuangNN (31/05/2014) - OK
//Grid - Tim hang thoa man dieu kien mang dong co xep
function Grid_Fi_TimHangXep(gridId, a_cot, a_gtri) {
    try {
        var b_hang = -1;

        for (var i = a_cot.length; i > 0; i--) {
            var a_cot_m = [], a_gtri_m = [], a_dk_m = [];

            for (var j = 0; j < i; j++) {
                a_cot_m[j] = a_cot[j].toUpperCase(); a_gtri_m[j] = a_gtri[j]; a_dk_m[j] = "==";
            }

            a_dk_m[i - 1] = "<=";
            b_hang = Grid_Fi_TimHangM(gridId, a_cot_m, a_gtri_m, a_dk_m);

            if (b_hang >= 0) {
                return b_hang;
            }
        }

        return b_hang;
    }
    catch (ex) { return -1; }
}

//QuangNN (31/05/2014) - OK
//Grid - Tim hang thoa man dieu kien don
function Grid_Fi_TimHang(gridId, b_cot, b_gtri) {
    b_cot = b_cot.toUpperCase();

    return Grid_Fi_TimHangD(gridId, b_cot, b_gtri, "==");
}

//QuangNN (31/05/2014) - OK
//Grid - Tim hang thoa man dieu kien mang
function Grid_Fi_TimHangN(gridId, a_cot, a_gtri) {
    var a_dk = [];
    for (var i = 0; i < a_cot.length; i++) a_dk[i] = "==";
    return Grid_Fi_TimHangND(gridId, a_cot, a_gtri, a_dk)
}

//QuangNN (31/05/2014)
//Grid - Chi Active Row khong show
function Grid_ChiActiveRow(gridId, b_hang) {
    Grid_DatActiveRow(gridId, b_hang);
}

//QuangNN (31/05/2014)
//Grid - Dat chon
function Grid_DatChon(gridId, b_hang) {
    Grid_DatActiveRow(gridId, b_hang);
}

//QuangNN (31/05/2014)
// Dat an, hien cột
function Grid_P_AnCot(gridId, b_cot, b_dat) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var a_cot = b_cot.split(','), b_coti = 0;

        if (b_dat) {
            for (var i = 0; i < a_cot.length; i++) b_grid.hideColumn(a_cot[i].trim());
        }
        else {
            for (var i = 0; i < a_cot.length; i++) b_grid.showColumn(a_cot[i].trim());
        }
    }
    catch (ex) { }
}

//QuangNN (31/05/2014)
// Tra tinh trang cot an, hien
function Grid_Fb_AnCot(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_coti = Grid_Fi_TtuCot(gridId, b_cot);

        if (b_coti < 0) return false;

        var b_status = b_grid.columns[b_coti].hidden;

        return (b_status === undefined) ? false : b_status;
    }
    catch (ex) { return false; }
}

//QuangNN (31/05/2014)
// Đặt cột được update hoặc không
function Grid_P_CotUpdate(gridId, b_cot, b_dat) {
    Grid_P_DatEditCell(gridId, b_cot, b_dat);
}

//Đặt lại Edittable
function Grid_P_DatEditCell(gridID, b_cot, b_dat) {
    try {
        var b_grid = $("#" + gridID).data("kendoGrid");
        var b_columns = b_grid.columns;
        var grid_editable = false;

        for (var i = 0; i < b_columns.length; i++) {
            var a_columns = b_cot.split(',');
            for (var j = 0; j < a_columns.length; j++) {
                if (b_columns[i].field.toUpperCase() == a_columns[j].toUpperCase()) {
                    b_columns[i].edit = b_dat;
                }
            }

            if (b_columns[i].edit) grid_editable = true;
        }

        $("#" + gridId).attr("editable", grid_editable);
    }
    catch (ex) { }
}

//QuangNN (04/06/2014)
// Đặt Grid được update hoặc không
function Grid_P_GridUpdate(gridId, b_dat) {
    try {
        var b_grid = $("#" + gridID).data("kendoGrid");

        $("#" + gridId).attr("editable", b_dat);
    }
    catch (ex) { }
}

//QuangNN (07/06/2014)
//Grid - Dat mau cac Cell trong 1 hang
function Grid_P_MauCell(gridId, b_hang, b_cot, b_nen, b_chu) {
    try {
        b_cot = b_cot.toUpperCase();

        var a_cot = (b_cot == "") ? Grid_Fas_TenCot(gridId) : b_cot.split(',');
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;

        for (var i = 0; i < a_cot.length; i++) {
            var b_icot = Grid_Fi_TtuCot(gridId, a_cot[i].trim());

            $("#" + gridId + " tbody tr:eq(" + b_hang + ") td:eq(" + b_icot + ")").css("background-color", b_nen);
            $("#" + gridId + " tbody tr:eq(" + b_hang + ") td:eq(" + b_icot + ")").css("color", b_chu);
        }
    }
    catch (ex) { }
}

//QuangNN (07/06/2014)
//Grid - Dat mau cac Cell trong cac hang co dieu kien don
function Grid_P_MauRow(gridId, b_cot, b_nen, b_chu, b_ten, b_ktra) {
    try {
        b_cot = b_cot.toUpperCase();
        b_ten = b_ten.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        for (var i = 0; i < b_rows.length; i++) {
            var b_gtri = Grid_Fobj_LayGtri(gridId, i, b_ten);

            if (b_gtri != null && b_gtri == b_ktra) Grid_P_MauCell(gridId, i, b_cot, b_nen, b_chu);
        }
    }
    catch (ex) { }
}

//QuangNN (07/06/2014)
//Grid - Dat mau theo dieu kien cac Cell trong cac hang co dieu kien don thuoc mang
function Grid_P_MauRowN(gridId, b_cot, b_nen, b_chu, b_ten, a_ktra) {
    try {
        b_cot = b_cot.toUpperCase();
        b_ten = b_ten.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var a_nen = b_nen.split(',');
        var a_chu = b_chu.split(',');
        var b_vtri = 0;

        for (var i = 0; i < b_rows.length; i++) {
            if (Grid_Fb_HangTrang(gridId, i)) break;

            var b_gtri = _Grid_Fobj_LayGtri(gridId, i, b_ten);

            if (b_gtri != null) {
                b_vtri = -1;

                for (var j = 0; j < a_ktra.length; j++) {
                    if (a_ktra[j] == b_gtri) {
                        b_vtri = j;
                        break;
                    }
                }

                if (b_vtri >= 0) Grid_P_MauCell(gridId, i, b_cot, a_nen[b_vtri].trim(), a_chu[b_vtri].trim());
            }
        }
    }
    catch (ex) { }
}

//QuangNN (07/06/2014)
//Grid - Tra nhan cot
function Grid_Fs_NhanCot(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;
        var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

        return b_columns[b_icot].title;
    }
    catch (ex) { return ""; }
}

//QuangNN (07/06/2014)
//Grid - Tra trang hien hanh
function Grid_Fi_TrangActive(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        return b_grid.dataSource.page();
    }
    catch (ex) { return 0; }
}

//QuangNN (04/07/2014)
//Grid - Tra ten cot active
function Grid_Fs_TenCotActive(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;

        return b_columns[b_grid.COL_SELECTED_INDEX].field;
    }
    catch (ex) { return ""; }
}

//QuangNN (07/06/2014)
//Grid - Tra ten cot noi thanh chuoi
function Grid_Fs_TenCot(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;

        var b_cot = "";
        for (var i = 0; i < b_columns.length; i++) b_cot += b_columns[i].field;

        return b_cot;
    }
    catch (ex) { return ""; }
}

//QuangNN (07/06/2014)
//Grid - Tra so cot
function Grid_Fi_SoCot(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;

        return b_columns.length;
    }
    catch (ex) { return 0; }
}

//QuangNN (08/06/2014)
//Grid - Tra do rong cot
function Grid_Fn_RongCot(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;
        var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

        return b_columns[b_icot].width;
    }
    catch (ex) { return 0; }
}

//QuangNN (08/06/2014)
//Grid - Tra kieu tat ca cac cot cot
function Grid_Fs_KieuCotN(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;
        var b_kieu = "";

        for (var i = 0; i < b_columns.length; i++) {
            if (b_columns[i].hasOwnProperty("type")) {
                b_kieu += b_columns[i].type;
            }
            else {
                b_kieu += "S";
            }
        }

        return b_kieu;
    }
    catch (ex) { return ""; }
}

//QuangNN (08/06/2014) - OK
//Grid - Tra ten, kieu tat ca cac cot cot
function Grid_Fas_TenKieu(gridId) {
    try {
        var a_cot = Grid_Fas_TenCot(gridId), b_kieu = Grid_Fs_KieuCotN(gridId);
        return [a_cot, b_kieu];
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri tat ca cac cot cua 1 hang
function Grid_Fdr_LayGtri(gridId, b_hang) {
    try {
        var a_cot = Grid_Fas_TenCot(gridId);
        return Grid_Fdr_LayGtriN(gridId, b_hang, a_cot);
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri vai cot tai hang dang Active
function Grid_Faobj_LayGtri_Act(gridId, a_cot) {
    var b_hang = Grid_Fi_HangActive(gridId);
    return (b_hang < 0) ? null : Grid_Fdr_LayGtriN(gridId, b_hang, a_cot);
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri tat ca cac cot tai hang dang Active
function Grid_Faobj_LayGtriN_Act(gridId) {
    var b_hang = Grid_Fi_HangActive(gridId);
    return (b_hang < 0) ? null : Grid_Fdr_LayGtri(gridId, b_hang);
}

//QuangNN (08/06/2014)
//Grid - Lay gia tri 1 cot cua bang
function Fdt_Grid_LayGtri(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_dt = [], b_hang = -1;

        for (var j = 0; j < b_rows.length; j++) {
            if (!Grid_Fb_HangTrang(gridId, j)) {
                b_hang++;
                b_dt[b_hang] = _Grid_Fobj_LayGtri(gridId, j, b_cot);
            }
        }
        return (b_hang < 0) ? null : b_dt;
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014)
//Grid - Lay gia tri vai cot cua bang
function Fdt_Grid_LayGtriN(gridId, a_cot) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_dt = [], b_hang = -1;

        for (var j = 0; j < b_rows.length; j++) {
            if (!Grid_Fb_HangTrang(gridId, j)) {
                b_hang++;
                b_dt[b_hang] = _Grid_Fdr_LayGtriN(gridId, j, a_cot);
            }
        }

        return (b_hang < 0) ? null : b_dt;
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri tat ca cac cot cua 1 bang
function Grid_Fdt_LayGtriT(gridId) {
    try {
        var a_cot = Grid_Fas_TenCot(gridId);
        return Fdt_Grid_LayGtriN(gridId, a_cot);
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri va ten vai cot cua bang
function Fdt_Grid_CotGtriN(gridId, a_cot) {
    try {
        var a_gtri = Fdt_Grid_LayGtriN(gridId, a_cot);
        return [a_cot, a_gtri];
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri tat ca ten cot va gia tri cua 1 bang
function Grid_Fdt_CotGtri(gridId) {
    try {
        var a_cot = Grid_Fas_TenCot(gridId);
        return Fdt_Grid_CotGtriN(gridId, a_cot);
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014) - OK
// Tra thu tu trong mang a_ten theo b_ten
function Fi_vtri_mang(a_ten, b_ten) {
    var b_vtri = -1;

    for (var i = 0; i < a_ten.length; i++) {
        if (a_ten[i].toUpperCase() == b_ten.toUpperCase()) {
            b_vtri = i;
            break;
        }
    }

    return b_vtri;
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri vai a_cot cua bang co loc trang cac cot a_loc
function Grid_Fdt_CotGtriL(gridId, a_cot, a_loc) {
    try {
        var a_gtri = Fdt_Grid_LayGtriN(gridId, a_cot);

        if (a_gtri == null || a_loc == null || a_loc.length == 0) return [a_cot, a_gtri];

        var b_icot = 0, b_kt = 0, b_log = true, a_moi = [];

        for (var i = 0; i < a_gtri.length; i++) {
            b_log = true;

            for (var j = 0; j < a_loc.length; j++) {
                b_icot = Fi_vtri_mang(a_cot, a_loc[j]);

                if (a_gtri[i][b_icot] == null || a_gtri[i][b_icot] == "" || a_gtri[i][b_icot] == 0) {
                    b_log = false; break;
                }
            }

            if (b_log) { a_moi[b_kt] = a_gtri[i]; b_kt++; }
        }
        return (a_moi.length == 0) ? [a_cot, null] : [a_cot, a_moi];
    }
    catch (ex) { return [a_cot, null]; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri tat ca cot cua bang co loc trang theo cac cot a_loc
function Grid_Fdt_CotGtriLT(gridId, a_loc) {
    try {
        var a_cot = Grid_Fas_TenCot(gridId);
        return Grid_Fdt_CotGtriL(gridId, a_cot, a_loc);
    }
    catch (ex) { return [a_cot, null]; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri vai a_cot cua bang co loc trang cac theo cot chu hoa
function Grid_Fdt_CotGtriH(gridId, a_cot) {
    try {
        var a_loc = [], b_kt = 0;
        for (var i = 0; i < a_cot.length; i++) {
            if (a_cot[i] == a_cot[i].toUpperCase()) { a_loc[b_kt] = a_cot[i]; b_kt++; }
        }
        return Grid_Fdt_CotGtriL(gridId, a_cot, a_loc)
    }
    catch (ex) { return [a_cot, null]; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri tat ca cot cua bang co loc trang theo cac cot chu hoa
function Grid_Fdt_CotGtriHT(gridId) {
    try {
        var a_cot = Grid_Fas_TenCot(gridId);
        return Grid_Fdt_CotGtriH(gridId, a_cot);
    }
    catch (ex) { return [a_cot, null]; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri vai a_cot cua bang co dieu kien
function Grid_Fdt_CotGtriD(gridId, a_cot, a_ten, a_ktra) {
    try {
        var all_cot = Grid_Fas_TenCot(gridId);
        var a_gtri = Fdt_Grid_LayGtriN(gridId, all_cot), b_kt = 0, b_log = true, a_moi = [];

        for (var i = 0; i < a_gtri.length; i++) {
            b_log = true;

            for (var j = 0; j < a_ten.length; j++) {
                var b_icot = Fi_vtri_mang(all_cot, a_ten[j].toUpperCase());

                if (a_gtri[i][b_icot] == null || a_gtri[i][b_icot] != a_ktra[j]) {
                    b_log = false;
                    break;
                }
            }


            if (b_log) {
                var a_gtri_c = [];

                for (var k = 0; k < a_cot.length; k++) {
                    var b_icot = Fi_vtri_mang(all_cot, a_cot[k].toUpperCase());

                    a_gtri_c[k] = a_gtri[i][b_icot];
                }

                a_moi[b_kt] = a_gtri_c; b_kt++;
            }
        }

        return [a_cot, a_moi];
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014) - OK
//Grid - Lay gia tri tat ca cot cua bang co dieu kien
function Grid_Fdt_CotGtriDT(gridId, a_ten, a_ktra) {
    try {
        var a_cot = Grid_Fas_TenCot(gridId);
        return Fdt_Grid_CotGtriD(gridId, a_cot, a_ten, a_ktra);
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014)
//Grid - Lấy giá trị các cột của bảng tại các hàng đang chọn
function Fdt_Grid_CotGtriC(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var a_cot = (b_cot != "") ? b_cot.split(',') : Grid_Fas_TenCot(gridId);
        var b_grid = $("#" + gridId).data("kendoGrid");
        var dataRows = b_grid.items();
        var b_dt = [], b_kt = 0;

        b_grid.select().each(function () {
            var b_hang = dataRows.index($(this));

            b_dt[b_kt] = Grid_Fdr_LayGtriN(gridId, b_hang, a_cot);
            b_kt++;
        });

        return b_dt;
    }
    catch (ex) { return null; }
}

//QuangNN (08/06/2014)
//Grid - Dat gia tri trang cho nhieu cot cach nhau dau phay
function Grid_DatTrangCot(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var a_cot = b_cot.split(','), a_gtri = [];

        for (var i = 0; i < a_cot.length; i++) a_gtri[i] = null;

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        for (var i = 0; i < b_rows.length; i++) Grid_P_DatGtriN(gridId, i, a_cot, a_gtri);
    }
    catch (ex) { }
}

//QuangNN (08/06/2014)
//Grid - Dat gia tri trang cho 1 hang
function Grid_DatTrang(gridId, b_hang) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;
        var b_rows = b_grid.dataSource.data();
        var b_row = b_rows[b_hang];

        if (b_row != null && b_row != undefined) {
            for (var i = 0; i < b_columns.length; i++) {
                b_row[b_columns[i].field] = null;
            }

            b_grid.refresh();
        }
    }
    catch (ex) { }
}

//QuangNN (08/06/2014) - OK
//Grid - Dat moi
function Grid_DatMoi(gridId) {
    try {
        Grid_ThoiActive(gridId); Grid_DatTrangCa(gridId);
    }
    catch (ex) { }
}

//QuangNN (09/06/2014) - OK
//Grid - Dat gia tri 1 cot tai hang Active
function Grid_P_DatGtri_Act(gridId, b_cot, b_gtri) {
    //debugger;
    b_cot = b_cot.toUpperCase();

    var b_hang = Grid_Fi_HangActive(gridId);
    if (b_hang >= 0) Grid_P_DatGtri(gridId, b_hang, b_cot, b_gtri);
}

//QuangNN (09/06/2014) - OK
//Grid - Dat gia tri nhieu cot tai hang Active
function Grid_P_DatGtriN_Act(gridId, a_cot, a_gtri) {
    var b_hang = Grid_Fi_HangActive(gridId);
    if (b_hang >= 0) Grid_P_DatGtriN(gridId, b_hang, a_cot, a_gtri);
}

//QuangNN (09/06/2014) - OK
// Tra gia tri trong mang a_gtri theo b_ten
function Fobj_gtri_mang(a_ten, a_gtri, b_ten) {
    b_ten = b_ten.toUpperCase();

    var b_vtri = Fi_vtri_mang(a_ten, b_ten);
    return (b_vtri < 0) ? null : a_gtri[b_vtri];
}

//QuangNN (09/06/2014) - OK
// Tra mang gia tri trong mang a_gtri theo mang a_tim
function Faobj_gtri_mang(a_ten, a_gtri, a_tim) {
    var a_tra = [];
    for (var i = 0; i < a_tim.length; i++) a_tra[i] = Fobj_gtri_mang(a_ten, a_gtri, a_tim[i]);
    return a_tra;
}

//QuangNN (09/06/2014) - OK
//Grid - Thay gia tri neu tim thay
function Grid_P_ThayGtri(gridId, b_tim, b_thay, b_cot, b_ch) {
    b_cot = b_cot.toUpperCase();

    var a_cot = (b_cot != "") ? b_cot.split(',') : Grid_Fas_TenCot(gridId);
    var a_tim = b_tim.split(','), a_thay = b_thay.split(','),
        b_hang = 0, a_gtri = [], a_ma = [], b_dt_t = Fdt_ChBang(b_ch);
    var b_dt_m = Fdt_Grid_ChLoai(a_cot, b_dt_t);
    for (var i = 0; i < b_dt_m.length; i++) {
        a_gtri = kytu_locUnicode(b_dt_m[i]);
        a_ma = Faobj_gtri_mang(a_cot, a_gtri, a_tim);
        b_hang = Grid_Fi_TimHangN(gridId, a_tim, a_ma);
        if (b_hang >= 0) {
            a_ma = Faobj_gtri_mang(a_cot, a_gtri, a_thay);
            Grid_P_DatGtriN(gridId, b_hang, a_thay, a_ma);
        }
    }
}

//QuangNN (30/05/2014) - OK
//Grid - Chen gia tri grid tu chuoi vao bang cu
function Grid_P_ChenBangCH(gridId, b_vtri, b_ch) {
    try {
        if (b_ch != "") {
            var a_cot = Grid_Fas_TenCot(gridId);
            var b_dt_t = Fdt_ChBang(b_ch);
            var b_dt_m = Fdt_Grid_ChLoai(a_cot, b_dt_t);

            Grid_P_ChenBang(gridId, b_vtri, a_cot, b_dt_m);
        }
    }
    catch (ex) { }
}

//QuangNN (30/05/2014)
// Cat dong
function Grid_P_CatDong(gridId, b_tu, b_den) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        b_rows.splice(b_tu, b_den - b_tu + 1);
    }
    catch (ex) { }
}
//Cắt tauij vị tri
function Grid_P_CatDongTai(gridId, b_hang) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        b_rows.splice(b_hang, 1);
        var r = Grid_CreateNewRow(gridId);
        b_rows.push(r);
    }
    catch (ex) { }
}
//QuangNN (30/05/2014)
//Grid - Tim Max 1 cot khong dieu kien
function Grid_Fn_Max_KDK(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_max = null;

        for (var i = 0; i < b_rows.length; i++) {
            var b_gtri = Grid_Fobj_LayGtri(gridId, i, b_cot);

            if (i == 0) b_max = b_gtri;
            else if (b_gtri != null && b_gtri != undefined && (b_max == null || b_gtri > b_max)) b_max = b_gtri;
        }

        return b_max;
    }
    catch (ex) { return null; }
}

//QuangNN (30/05/2014)
//Grid - Tim số thứ tự tiếp theo 1 cot
function Grid_Fi_sott(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_sott = 0, b_gtri = 0;

        for (var i = 0; i < b_rows.length; i++) {
            b_gtri = Grid_Fobj_LayGtri(gridId, i, b_cot);

            if (b_gtri != null && b_gtri != undefined && b_gtri < 1000000 && b_grid > b_sott) b_sott = b_gtri;
        }

        return b_sott + 1;
    }
    catch (ex) { return 1; }
}

//QuangNN (30/05/2014)
//Grid - Tinh tong 1 cot khong dieu kien
function Grid_Fn_Tong_KDK(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_tong = 0;

        for (var i = 0; i < b_rows.length; i++) {
            var b_gtri = Grid_Fobj_LayGtri(gridId, i, b_cot);

            if (b_gtri != null) b_tong += CSO_SO(b_gtri, 0);
        }

        return b_tong;
    }
    catch (ex) { return 0; }
}

//QuangNN (30/05/2014)
//Grid - Tinh tong nhieu cot khong dieu kien
function Grid_Fan_Tong_KDK(gridId, a_cot) {
    var a_kq = [];

    for (var i = 0; i < a_cot.length; i++) a_kq[i] = Grid_Fn_Tong_KDK(gridId, a_cot[i].toUpperCase());

    return a_kq;
}

//QuangNN (30/05/2014)
//Grid - Tinh tong 1 cot dieu kien don
function Grid_Fn_Tong(gridId, b_cot, b_ten, b_ktra) {
    try {
        b_cot = b_cot.toUpperCase();
        b_ten = b_ten.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_tong = 0;

        for (var i = 0; i < b_rows.length; i++) {
            var b_gtri_ktra = Grid_Fobj_LayGtri(gridId, i, b_ten);

            if (b_gtri_ktra != null && b_gtri_ktra == b_ktra) {
                var b_gtri = Grid_Fobj_LayGtri(gridId, i, b_cot);

                if (b_gtri != null) b_tong += CSO_SO(b_gtri, 0);
            }
        }
        return b_tong;
    }
    catch (ex) { return 0; }
}



//QuangNN (30/05/2014)
//Grid - Kiem tra ca Grid trang
function Grid_Fb_GridTrang(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        for (var i = 0; i < b_rows.length; i++)
            if (!Grid_Fb_HangTrang(gridId, i)) return false;

        return true;
    }
    catch (ex) { return true; }
}

//QuangNN (29/05/2014)
//Grid - Chen dong tai hang active
function Grid_ChenDong(gridId) {
    var b_hang = Grid_Fi_HangActive(gridId);

    if (b_hang < 0) return;

    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();

    var newRow = Grid_CreateNewRow(gridId);
    b_rows.splice(b_hang, 0, newRow);
}

//QuangNN (29/05/2014)
//Grid - Chen tai hang
function Grid_ChenTai(gridId, b_hang) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();

    if (!Grid_Fb_HangTrang(gridId, b_hang) || b_hang >= b_rows.length) {
        var newRow = Grid_CreateNewRow(gridId);

        b_rows.splice(b_hang, 0, newRow);
    }
}

//QuangNN (29/05/2014)
//Grid - Thêm hàng trắng cuối lưới nếu hàng cuối lưới không phải là hàng trắng
function Grid_ThemCuoi(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();

    if (!Grid_Fb_HangTrang(gridId, b_rows.length - 1)) {
        var newRow = Grid_CreateNewRow(gridId);
        b_rows.push(newRow);
    }
}

//QuangNN (29/05/2014)
//Grid - Giu lai hang da chon
function Grid_giuRowSelect(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var data = [];

        b_grid.select().each(function () {
            var dataItem = b_grid.dataItem($(this));
            data.push(dataItem.toJSON());

        });

        Grid_P_DatBangCH(gridId, JSON.stringify(data));

        //var b_grid = $("#" + gridId).data("kendoGrid");
        //var b_rows = b_grid.dataSource.data();

        //$("#" + gridId + " tbody").find("tr:not(.k-state-selected)").each(function () {
        //    b_grid.removeRow($(this));

        //    var newRow = Grid_CreateNewRow(gridId);
        //    b_rows.push(newRow);
        //});
    }
    catch (ex) { }
}

//QuangNN (28/05/2014)
//Grid - Tra kich thuoc trang
function Grid_Fi_TrangKt(gridId) {
    try {
        return $("#" + gridId).attr("page_size");
    }
    catch (ex) { return 0; }
}

//QuangNN (29/05/2014)
//Create new row
function Grid_CreateNewRow(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_columns = b_grid.columns;
    var newRow = new Object();

    for (var i = 0; i < b_columns.length; i++) newRow[b_columns[i].field] = null;

    return newRow;
}

//QuangNN (11/07/2014)
//Grid - Chuyển chỉ số hàng trên lưới thành hàng dữ liệu
function Grid_Fi_DataRowIndex(gridId, b_hang) {
    try {
        if (b_hang == -1) return -1;

        var b_grid = $("#" + gridId).data("kendoGrid");
        var page_number = b_grid.dataSource.page();
        var page_size = b_grid.dataSource.pageSize();

        if (page_number !== undefined && page_size !== undefined) {
            return b_hang + (page_number - 1) * page_size;
        }
        else {
            return b_hang;
        }
    }
    catch (ex) { return -1; }
}

//QuangNN (11/07/2014)
//Grid - Chuyển chỉ số hàng dữ liệu thành hàng trên lưới
function Grid_Fi_GridRowIndex(gridId, b_hang) {
    try {
        if (b_hang == -1) return -1;

        var b_grid = $("#" + gridId).data("kendoGrid");
        var page_size = b_grid.dataSource.pageSize();

        if (page_size !== undefined) {
            return b_hang % page_size;
        }
        else {
            return b_hang;
        }
    }
    catch (ex) { return -1; }
}

//QuangNN (26/05/2014) - Grid_DatActiveRow
//Grid - Them hang sau update cell
function Grid_ThemHang(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        var b_rows = b_grid.dataSource.data();
        var b_hang_c = b_grid.ROW_SELECTED_INDEX;
        var b_icot_c = b_grid.COL_SELECTED_INDEX;

        if (!b_grid.pageable && b_hang_c == b_rows.length - 1 && !Grid_Fb_HangTrang(gridId, b_hang_c)) {
            var newRow = Grid_CreateNewRow(gridId);

            b_rows.push(newRow);

            var b_icot = 0;
            var b_columns = b_grid.columns;

            while (b_icot < b_columns.length) {
                if (b_columns[b_icot].edit && !b_columns[b_icot].hidden) {
                    Grid_CloseCell(gridId, b_hang_c, b_icot_c);

                    var b_hang = b_hang_c + 1;
                    Grid_DatActiveRow(gridId, b_hang);
                    Grid_EditCell(gridId, b_hang, b_icot);

                    return;
                }

                b_icot++;
            }
        }

        Grid_DatActiveRow(gridId, b_hang_c);
        Grid_EditCell(gridId, b_hang_c, b_icot_c);
    }
    catch (ex) { }
}

//QuangNN (19/06/2014) - Grid_DatActiveRow
//Grid - Chuyen len hang tren
function Grid_NhayCot_Tren(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        var b_columns = b_grid.columns;
        var b_hang = b_grid.ROW_SELECTED_INDEX;
        var b_icot = b_grid.COL_SELECTED_INDEX;

        if (b_hang > 0 && b_columns[b_icot].edit && !b_columns[b_icot].hidden && !isDisabledCell(gridId, b_hang - 1, b_columns[b_icot].field)) {
            Grid_CloseCell(gridId, b_hang, b_icot);
            Grid_ThoiActive(gridId);
            Grid_DatActiveRow(gridId, b_hang - 1);
            Grid_EditCell(gridId, b_hang - 1, b_icot);

            return;
        }

        Grid_DatActiveRow(gridId, b_hang);
        Grid_EditCell(gridId, b_hang, b_icot);
    }
    catch (ex) { }
}

//QuangNN (19/06/2014) - Grid_DatActiveRow
//Grid - Chuyen xuong hang duoi
function Grid_NhayCot_Duoi(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        var b_columns = b_grid.columns;
        var b_rows = b_grid.dataSource.data();
        var b_hang = b_grid.ROW_SELECTED_INDEX;
        var b_icot = b_grid.COL_SELECTED_INDEX;

        if (b_hang + 1 < b_rows.length && b_columns[b_icot].edit && !b_columns[b_icot].hidden && !isDisabledCell(gridId, b_hang + 1, b_columns[b_icot].field)) {
            Grid_CloseCell(gridId, b_hang, b_icot);
            Grid_ThoiActive(gridId);
            Grid_DatActiveRow(gridId, b_hang + 1);
            Grid_EditCell(gridId, b_hang + 1, b_icot);

            return;
        }

        Grid_DatActiveRow(gridId, b_hang);
        Grid_EditCell(gridId, b_hang, b_icot);
    }
    catch (ex) { }
}

//QuangNN (19/06/2014) - Grid_DatActiveRow
//Grid - Chuyen sang ben trai
function Grid_NhayCot_Trai(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        var b_columns = b_grid.columns;
        var b_hang = b_grid.ROW_SELECTED_INDEX;
        var b_icot_c = b_grid.COL_SELECTED_INDEX;
        var b_icot_m = b_icot_c;

        while (b_icot_m > 0 && (b_columns[b_icot_m - 1].hidden || !b_columns[b_icot_m - 1].edit || isDisabledCell(gridId, b_hang, b_columns[b_icot_m - 1].field))) {
            b_icot_m--;
        }

        if (b_icot_m > 0 && !b_columns[b_icot_m - 1].hidden && b_columns[b_icot_m - 1].edit && !isDisabledCell(gridId, b_hang, b_columns[b_icot_m - 1].field)) {
            Grid_CloseCell(gridId, b_hang, b_icot_c);
            Grid_ThoiActive(gridId);
            Grid_DatActiveRow(gridId, b_hang);
            Grid_EditCell(gridId, b_hang, b_icot_m - 1);
            return;
        }

        Grid_DatActiveRow(gridId, b_hang);
        Grid_EditCell(gridId, b_hang, b_icot_c);
    }
    catch (ex) { }
}

//QuangNN (19/06/2014) - Grid_DatActiveRow
//Grid - Chuyen sang ben phai
function Grid_NhayCot_Phai(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        var b_columns = b_grid.columns;
        var b_hang = b_grid.ROW_SELECTED_INDEX;
        var b_icot_c = b_grid.COL_SELECTED_INDEX;
        var b_icot_m = b_icot_c;

        while (b_icot_m + 1 < b_columns.length && (b_columns[b_icot_m + 1].hidden || !b_columns[b_icot_m + 1].edit || isDisabledCell(gridId, b_hang, b_columns[b_icot_m + 1].field))) {
            b_icot_m++;
        }

        if (b_icot_m + 1 < b_columns.length && !b_columns[b_icot_m + 1].hidden && b_columns[b_icot_m + 1].edit && !isDisabledCell(gridId, b_hang, b_columns[b_icot_m + 1].field)) {
            Grid_CloseCell(gridId, b_hang, b_icot_c);
            Grid_ThoiActive(gridId);
            Grid_DatActiveRow(gridId, b_hang);
            Grid_EditCell(gridId, b_hang, b_icot_m + 1);
            return;
        }

        Grid_DatActiveRow(gridId, b_hang);
        Grid_EditCell(gridId, b_hang, b_icot_c);
    }
    catch (ex) { }
}

//QuangNN (16/06/2014) - Grid_DatActiveRow
//Grid - Chuyen den cot bat ky
function Grid_NhayCot_Ten(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        var b_columns = b_grid.columns;
        var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

        if (b_columns[b_icot].edit && !b_columns[b_icot].hidden && !isDisabledCell(gridId, b_hang, b_columns[b_icot].field)) {
            var b_hang = b_grid.ROW_SELECTED_INDEX;
            var b_icot_c = b_grid.COL_SELECTED_INDEX;

            Grid_CloseCell(gridId, b_hang, b_icot_c);
            Grid_ThoiActive(gridId);
            Grid_DatActiveRow(gridId, b_hang);
            Grid_EditCell(gridId, b_hang, b_icot);

            return;
        }

        Grid_DatActiveRow(gridId, b_hang);
        Grid_EditCell(gridId, b_hang, b_icot_c);
    }
    catch (ex) { }
}

//QuangNN (28/05/2014) - Grid_DatActiveRow
//Grid - Chuyen sang edit Cell tiep theo
function Grid_NhayCot(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        var b_rows = b_grid.dataSource.data();
        var b_columns = b_grid.columns;
        var b_hang_c = b_grid.ROW_SELECTED_INDEX;
        var b_icot_c = b_grid.COL_SELECTED_INDEX;
        var b_hang = b_hang_c;
        var b_icot = b_icot_c;

        while (b_hang < b_rows.length) {
            if (b_icot < b_columns.length - 1) b_icot++;
            else {
                b_hang++;
                b_icot = 0;
            }

            if (b_hang < b_rows.length && b_columns[b_icot].edit && !b_columns[b_icot].hidden && !isDisabledCell(gridId, b_hang, b_columns[b_icot].field)) {
                Grid_CloseCell(gridId, b_hang_c, b_icot_c);
                Grid_ThoiActive(gridId);
                Grid_DatActiveRow(gridId, b_hang);
                Grid_EditCell(gridId, b_hang, b_icot);

                return;
            }
        }

        //Thêm một hàng
        Grid_ThemHang(gridId);
    }
    catch (ex) { }
}

//QuangNN (07/08/2014) - Grid_DatActiveRow
//Grid - Chuyen sang edit Cell truoc do
function Grid_NhayCotLui(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return;

        var b_rows = b_grid.dataSource.data();
        var b_columns = b_grid.columns;
        var b_hang_c = b_grid.ROW_SELECTED_INDEX;
        var b_icot_c = b_grid.COL_SELECTED_INDEX;
        var b_hang_m = b_hang_c;
        var b_icot_m = b_icot_c;

        while (b_hang_m >= 0) {
            if (b_icot_m > 0) b_icot_m--;
            else {
                b_hang_m--;
                b_icot_m = b_columns.length - 1;
            }

            if (b_hang_m >= 0 && b_columns[b_icot_m].edit && !b_columns[b_icot_m].hidden && !isDisabledCell(gridId, b_hang, b_columns[b_icot].field)) {
                Grid_CloseCell(gridId, b_hang_c, b_icot_c);
                Grid_ThoiActive(gridId);
                Grid_DatActiveRow(gridId, b_hang_m);
                Grid_EditCell(gridId, b_hang_m, b_icot_m);

                return;
            }
        }

        Grid_DatActiveRow(gridId, b_hang_c);
        Grid_EditCell(gridId, b_hang_c, b_icot_c);
    }
    catch (ex) { }
}

//QuangNN (28/05/2014)
//Grid - Thôi active Row
function Grid_BoDatChon(gridId) {
    Grid_ThoiActive(gridId);
}

//QuangNN (28/05/2014)
//Active Row
function Grid_DatActiveRow(gridId, b_hang) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    b_grid.select("#" + gridId + " tbody tr:eq(" + b_hang + ")");
}

//QuangNN (28/05/2014)
//Edit Cell
function Grid_EditCell(gridId, b_hang, b_icot) {
    var b_grid = $("#" + gridId).data("kendoGrid");

    b_grid.editCell("#" + gridId + " tbody tr:eq(" + b_hang + ") td:eq(" + b_icot + ")");

    var grid_editable = $("#" + gridId).attr("editable");
    if (grid_editable === undefined || grid_editable === null || grid_editable != 'false') {
        $("#" + gridId + " tbody tr:eq(" + b_hang + ")").addClass('k-state-selected-ext');
    }
}

//QuangNN (28/05/2014)
//Close Cell - đặt cell không còn trong chế dộ edit
function Grid_CloseCell(gridId, b_hang, b_icot) {
    var b_grid = $("#" + gridId).data("kendoGrid");

    b_grid.closeCell("#" + gridId + " tbody tr:eq(" + b_hang + ") td:eq(" + b_icot + ")");

    var grid_editable = $("#" + gridId).attr("editable");
    if (grid_editable === undefined || grid_editable === null || grid_editable != 'false') {
        $("#" + gridId + " tbody tr:eq(" + b_hang + ")").removeClass('k-state-selected-ext');
    }
}

//QuangNN (28/05/2014) - Grid_DatActiveRow
//Grid - Doi vi tri 2 hang
function Grid_DoiGtri(gridId, b_hang, b_hang_m, b_doi) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        var temp = b_rows[b_hang];
        b_rows[b_hang] = b_rows[b_hang_m];
        b_rows[b_hang_m] = temp;
        b_grid.refresh();

        if (b_doi == 'C') Grid_DatActiveRow(gridId, Grid_Fi_GridRowIndex(gridId, b_hang_m));
    }
    catch (ex) { }
}

//QuangNN (28/05/2014)
//Grid - Chuyen hang len
function Grid_HangLen(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_hang = Grid_Fi_HangActive(gridId);

    //if (Grid_Fb_HangTrang(gridId, b_hang)) return;
    if (b_hang > 0) Grid_DoiGtri(gridId, b_hang, b_hang - 1, 'C');
}

//QuangNN (28/05/2014)
//Grid - Chuyen hang xuong
function Grid_HangXuong(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();
    var b_hang = Grid_Fi_HangActive(gridId);

    if (b_hang < b_rows.length - 1) Grid_DoiGtri(gridId, b_hang, b_hang + 1, 'C');

    //var b_hang_trang = Grid_Fi_HangTrang(gridId);
    //if (b_hang_trang == -1) {
    //    if (b_hang < b_rows.length - 1) Grid_DoiGtri(gridId, b_hang, b_hang + 1, 'C');
    //}
    //else {
    //    if (b_hang < b_hang_trang - 1) Grid_DoiGtri(gridId, b_hang, b_hang + 1, 'C');
    //}
}

//QuangNN (26/05/2014)
//Grid - Tra so dong hien co cua grid
function Grid_Fi_soDong(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        return b_rows.length;
    }
    catch (ex) { return 0; }
}

//QuangNN (26/05/2014)
//Grid - Tim hang trang dau tien
function Grid_Fi_HangTrang(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        for (var i = 0; i < b_rows.length; i++)
            if (Grid_Fb_HangTrang(gridId, i)) return i;

        return -1;
    }
    catch (ex) { return -1; }
}

//QuangNN (26/05/2014)
//Grid - Tim hang da nhap cuoi
function Grid_Fi_HangNhap(gridId) {
    try {
        var b_hang = Grid_Fi_HangTrang(gridId);

        if (b_hang >= 0) b_hang--;
        else b_hang = Grid_Fi_soDong(gridId) - 1;

        return b_hang;
    }
    catch (ex) { return -1; }
}

//QuangNN (23/05/2014)
//Grid - Thoi Active Row
function Grid_ThoiActive(gridId) {
    var b_grid = $("#" + gridId).data("kendoGrid");
    b_grid.clearSelection();

    //QuangNN - Cách 2
    //b_grid.select().each(function () {       
    //    $(this).removeClass("k-state-selected");
    //});
}

//QuangNN (23/05/2014) - Đã duyệt
//Grid - Lay gia tri 1 cot tai hang dang Active
function Grid_Fobj_LayGtri_Act(gridId, b_cot) {
    b_cot = b_cot.toUpperCase();

    var b_hang = Grid_Fi_HangActive(gridId);
    return (b_hang < 0) ? null : Grid_Fobj_LayGtri(gridId, b_hang, b_cot);
}

//QuangNN (22/05/2014)
//Grid - Dat gia tri nhieu cot
function Grid_P_DatGtriN(gridId, b_hang, a_cot, a_gtri) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        if (b_hang >= 0 && b_hang < b_rows.length) {
            var b_row = b_rows[b_hang];

            for (var i = 0; i < a_cot.length; i++) {
                if (b_row.hasOwnProperty(a_cot[i].toUpperCase())) b_row[a_cot[i].toUpperCase()] = a_gtri[i];
            }
        }

        b_grid.refresh();
    }
    catch (ex) { }
}

//QuangNN (22/05/2014)
//Grid - Tao Grid trống không có hàng
function Grid_DatTrong(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        b_grid.dataSource.data([]);
    }
    catch (ex) { }
}

//QuangNN (22/05/2014) - OK
// Tra ID Grid theo 1 ten
function form_Fs_Grid_ID(b_vung, b_ten) {
    try {
        var b_vungId = form_Fs_VUNG_ID(b_vung);
        var b_vung = form_Fctr_VUNG(b_vungId);
        b_ten = b_ten.toUpperCase() + "_ID";
        var a_ctr = b_vung.getElementsByTagName("input");
        for (var i = 0; i < a_ctr.length; i++) {
            if (a_ctr[i].id != null && a_ctr[i].id.toUpperCase() == b_ten) return a_ctr[i].value;
        }
        return "";
    }
    catch (err) { return ""; }
}

//QuangNN (26/05/2014)
//Lấy đầy đủ địa chỉ URL
function getFullURL(str) {
    var baseURL = getBaseURL();

    if (startsWith(str, "~/")) return baseURL + str.substring(1);
    else return str;
}

//QuangNN (21/05/2014)
function getBaseURL() {
    var pathname = window.location.pathname;
    var baseURL = pathname.substr(0, pathname.indexOf("/", 2));

    return baseURL;
}


//Cập nhật giá trị trên Grid theo giá trị được nhập trên Checkbox Editor
function Grid_CheckboxEditor_change(b_ctr, gridId, b_cot, nextFocus) {
    try {
        // debugger; 
        nextFocus = typeof nextFocus !== 'undefined' ? nextFocus : true;
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        // var b_hang = Grid_Fi_HangActive(gridId);
        var b_hang = Grid_Fi_GridHangActive(gridId);

        var hangTim = Grid_Fi_DataRowIndex(gridId, b_hang);

        if (hangTim >= 0 && hangTim < b_rows.length) {
            //update data            
            if (b_rows[hangTim][b_cot] == undefined || b_rows[hangTim][b_cot] == false || b_rows[hangTim][b_cot].toString().toUpperCase() == "FALSE") b_rows[hangTim][b_cot] = true;
            else b_rows[hangTim][b_cot] = false;

            var b_onUpdateCell = $("#" + gridId).attr("updateCell");

            if (typeof b_onUpdateCell !== 'undefined') {
                window[b_onUpdateCell](b_ctr, gridId, b_cot, hangTim, b_rows[hangTim][b_cot]);
            }

            //b_grid.refresh();

            //focus
            if (nextFocus == false) {
                Grid_DatActiveCell(gridId, b_hang, b_cot);
            }
            else if (nextFocus == true) {
                //next focus
                Grid_NhayCot(gridId);
            }
            else if (nextFocus != "") {
                //Nhảy tới cột
                Grid_NhayCot_Ten(gridId, nextFocus);
            }
        }
    }
    catch (err) { }
}
function Grid_CustomEditor_change_Drop(b_ctr, gridId, b_cot, nextFocus) {
    try {
        // debugger;
        nextFocus = typeof nextFocus !== 'undefined' ? nextFocus : true;
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_hang = Grid_Fi_HangActive(gridId);

        if (b_hang >= 0 && b_hang < b_rows.length && b_rows[b_hang].hasOwnProperty(b_cot)) {
            //update data
            if (b_ctr.getAttribute("kieudl") == "Date") {
                var b_loi = Fs_NGAY_LOI(b_ctr.value, "C");
                if (b_loi != "") {
                    alert(b_loi);
                    return false;
                }
            }
            if (b_ctr.value != '') {
                b_rows[b_hang]["ID_" + b_cot] = $(b_ctr).val();
                b_rows[b_hang][b_cot] = $(b_ctr).find('option:selected').text();
            }
            else b_rows[b_hang][b_cot] = null;

            var b_onUpdateCell = $("#" + gridId).attr("updateCell");

            if (typeof b_onUpdateCell !== 'undefined') {
                window[b_onUpdateCell](b_ctr, gridId, b_cot, b_hang, b_ctr.value);
            }

            //b_grid.refresh();

            //focus
            if (nextFocus == false) {
                Grid_DatActiveCell(gridId, b_hang, b_cot);
            }
            else if (nextFocus == true) {
                //next focus
                Grid_NhayCot(gridId);
            }
            else if (nextFocus != "") {
                //Nhảy tới cột
                Grid_NhayCot_Ten(gridId, nextFocus);
            }
        }
    }
    catch (err) { }
}

//QuangNN (21/05/2014)
//Cập nhật giá trị trên Grid theo giá trị được nhập trên Custom Editor
function Grid_CustomEditor_change(b_ctr, gridId, b_cot, nextFocus) {
    try {
        nextFocus = typeof nextFocus !== 'undefined' ? nextFocus : true;
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_hang = Grid_Fi_HangActive(gridId);

        if (b_hang >= 0 && b_hang < b_rows.length && b_rows[b_hang].hasOwnProperty(b_cot)) {
            //update data
            if (b_ctr.getAttribute("kieudl") == "Date") {
                var b_loi = Fs_NGAY_LOI(b_ctr.value, "C");
                if (b_loi != "") {
                    alert(b_loi);
                    return false;
                }
            }
            if (b_ctr.value != '') {
                //chan XSS bang cach chan cac the html ko cho nhap vao luoi
                b_rows[b_hang][b_cot] = stripHtml(b_ctr.value);
                //b_rows[b_hang][b_cot] = b_ctr.value;

            }
            else b_rows[b_hang][b_cot] = null;

            var b_onUpdateCell = $("#" + gridId).attr("updateCell");

            if (typeof b_onUpdateCell !== 'undefined') {

                window[b_onUpdateCell](b_ctr, gridId, b_cot, b_hang, b_ctr.value);
            }

            //b_grid.refresh();

            //focus
            if (nextFocus == false) {
                Grid_DatActiveCell(gridId, b_hang, b_cot);
            }
            else if (nextFocus == true) {
                //next focus
                Grid_NhayCot(gridId);
            }
            else if (nextFocus != "") {
                //Nhảy tới cột
                Grid_NhayCot_Ten(gridId, nextFocus);
            }
        }
    }
    catch (err) { }
}

//QuangNN (21/05/2014)
//Cập nhật giá trị trên Grid theo giá trị được nhập trên Custom Editor
//Hướng: Trên - U, Dưới - D, Trái - L, Phải - R
function Grid_CustomEditor_Change_Huong(b_ctr, gridId, b_cot, b_huong) {
    try {
        b_huong = typeof b_huong !== 'undefined' ? b_huong : 'R';
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_hang = Grid_Fi_HangActive(gridId);

        if (b_hang >= 0 && b_hang < b_rows.length && b_rows[b_hang].hasOwnProperty(b_cot)) {
            //update data
            if (b_ctr.getAttribute("kieudl") == "Date") {
                var b_loi = Fs_NGAY_LOI(b_ctr.value, "C");
                if (b_loi != "") {
                    alert(b_loi);
                    return false;
                }
            }
            if (b_ctr.value != '') b_rows[b_hang][b_cot] = b_ctr.value;
            else b_rows[b_hang][b_cot] = null;

            var b_onUpdateCell = $("#" + gridId).attr("updateCell");

            if (typeof b_onUpdateCell !== 'undefined') {
                window[b_onUpdateCell](b_ctr, gridId, b_cot, b_hang, b_ctr.value);
            }

            //b_grid.refresh();

            //focus
            switch (b_huong) {
                case 'U':
                    Grid_NhayCot_Tren(gridId);
                    break;

                case 'D':
                    Grid_NhayCot_Duoi(gridId);
                    break;

                case 'L':
                    Grid_NhayCot_Trai(gridId);
                    break;

                case 'R':
                    Grid_NhayCot_Phai(gridId);
                    break;

                case 'PREVIOUS':
                    Grid_NhayCotLui(gridId);
                    break;
            }
        }
    }
    catch (err) { }
}

//QuangNN (19/05/2014) - Grid_DatActiveRow
//Grid - Dat Active Cell theo hang, cot
function Grid_DatActiveCell(gridId, b_hang, b_cot) {
    b_cot = b_cot.toUpperCase();

    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_columns_count = b_grid.columns.length;
    var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

    if (b_icot >= 0) {
        Grid_DatActiveRow(gridId, b_hang);
        Grid_EditCell(gridId, b_hang, b_icot);
    }
}

//QuangNN (19/05/2013)
//"S": string (default), "N": Number, "B": Boolean, "D": Date
//Grid - Tra kieu cot - Mặc định trả về kiểu S - String
function Grid_Fs_KieuCot(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;
        var b_type = "S";

        for (var i = 0; i < b_columns.length; i++) {
            if (b_columns[i].field == b_cot) {
                if (b_columns[i].hasOwnProperty("type")) {
                    return b_columns[i].type;
                }
                else {
                    return "S";
                }
            }
        }
    }
    catch (ex) { return "S"; }
}

//QuangNN (19/05/2014)
//Grid - Tim thu tu cot theo ten cot
function Grid_Fi_TtuCot(gridId, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;

        for (var i = 0; i < b_columns.length; i++) {
            if (b_columns[i].field == b_cot) return i;
        }

        return -1;
    }
    catch (ex) { return -1; }
}

//QuangNN (19/05/2014)
//Grid - Lay gia tri 1 cot cua hang
function _Grid_Fobj_LayGtri(gridId, b_hang, b_cot) {
    b_cot = b_cot.toUpperCase();

    var b_grid = $("#" + gridId).data("kendoGrid");
    var b_rows = b_grid.dataSource.data();

    var b_gtri = b_rows[b_hang][b_cot];

    if (b_gtri == null) {
        var b_kieu = Grid_Fs_KieuCot(gridId, b_cot);

        if (b_kieu == "N") b_gtri = 0;
        else if (b_kieu == "D") b_gtri = CNG_NG("01/01/3000");
    }

    return b_gtri;
}

function Grid_Fobj_LayGtri(gridId, b_hang, b_cot) {
    try {
        b_cot = b_cot.toUpperCase();

        if (Grid_Fb_HangTrang(gridId, b_hang)) return null;

        return _Grid_Fobj_LayGtri(gridId, b_hang, b_cot);
    }
    catch (ex) { return null; }
}

//QuangNN (19/05/2014)
//Grid - Lay gia tri vai cot cua 1 hang
function _Grid_Fdr_LayGtriN(gridId, b_hang, a_cot) {
    var b_dr = [];
    for (var i = 0; i < a_cot.length; i++) b_dr[i] = _Grid_Fobj_LayGtri(gridId, b_hang, a_cot[i].toUpperCase());
    return b_dr;
}

//QuangNN (08/06/2014) - OK
function Grid_Fdr_LayGtriN(gridId, b_hang, a_cot) {
    try {
        if (Grid_Fb_HangTrang(gridId, b_hang)) return null;

        return _Grid_Fdr_LayGtriN(gridId, b_hang, a_cot);
    }
    catch (ex) { return null; }
}

//QuangNN (16/05/2014)
//Grid - Lay gia tri tat ca ten cot va gia tri tai hang dang Active
function Grid_Fdr_CotGtri_Act(gridId) {
    var b_hang = Grid_Fi_HangActive(gridId);

    if (b_hang < 0 || Grid_Fb_HangTrang(gridId, b_hang)) return null;

    var a_cot = Grid_Fas_TenCot(gridId);

    return [a_cot, _Grid_Fdr_LayGtriN(gridId, b_hang, a_cot)];
}

//QuangNN (16/05/2014)
//Grid - Tra ve mang ten cot
function Grid_Fas_TenCot(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_columns = b_grid.columns;

        var a_cot = [];
        for (var i = 0; i < b_columns.length; i++) a_cot[i] = b_columns[i].field;

        return a_cot;
    }
    catch (ex) { return []; }
}

//QuangNN (16/05/2014)
//Grid - Tra hang du lieu dang active
function Grid_Fi_HangActive(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var dataRows = b_grid.items();

        return Grid_Fi_DataRowIndex(gridId, dataRows.index(b_grid.select()));
    }
    catch (ex) { return -1; }
}

//QuangNN (11/07/2014)
//Grid - Tra hang tren luoi dang active
function Grid_Fi_GridHangActive(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (b_grid.ROW_SELECTED_INDEX == -1 || b_grid.COL_SELECTED_INDEX == -1) return -1;

        return b_grid.ROW_SELECTED_INDEX;
    }
    catch (ex) { return -1; }
}

//QuangNN (16/05/2014)
//Grid - Kiem tra hang trang
function Grid_Fb_HangTrang(gridId, b_hang) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        if (b_hang >= b_rows.length) return true;

        var b_row = b_rows[b_hang];
        var b_columns = b_grid.columns;

        for (var i = 0; i < b_columns.length; i++) {
            if (b_row[b_columns[i].field] != null) {
                return false;
            }
        }

        return true;
    }
    catch (ex) { return true; }
}

//QuangNN (14/05/2014)
//Hàm trộn các tham số - được sử dụng cho các hàm lấy các tham số tùy chọn
function mergeArguments() {
    var obj, name, copy,
        target = arguments[0] || {},
        i = 1,
        length = arguments.length;

    for (; i < length; i++) {
        if (arguments[i] != null) {
            jQuery.extend(target, arguments[i]);
        }
    }

    return target;
}

//QuangNN (15/05/2014)
//Thêm các dòng dữ liệu liệu trắng cho đủ số row
function parseGridData(b_kq, minRowNumber, fieldNames) {
    minRowNumber = typeof minRowNumber !== 'undefined' ? minRowNumber : 0;

    var data = $.parseJSON(b_kq);
    var length = data.length;

    if (minRowNumber > 0 && minRowNumber > length) {
        //


        if (typeof fieldNames !== 'undefined') {
            for (var i = 0; i < minRowNumber - length; i++) {
                var obj = {};

                for (var j = 0; j < fieldNames.length; j++) {
                    obj[fieldNames[j].toUpperCase()] = null
                }

                data.push(obj);
            }
        }
    }

    return data;
}

//Ham tra ve so ngay trong thang
function DayOfMonth(month, year) {
    var b_ngay = 0;
    if (parseInt(month) == 2) {
        b_year = parseInt(year)
        if ((b_year % 4 == 0 && b_year % 100 != 0) || (b_year % 400 == 0))
            b_ngay = 29;
        else
            b_ngay = 28;
    }
    else {
        switch (parseInt(month)) {
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
                b_ngay = 31;
                break;
            case 4:
            case 6:
            case 9:
            case 11:
                b_ngay = 30;
                break;
        }
    }
    return b_ngay;
}
function contro_vtri(b_ctr) {
    try {
        var b_vtri = 0;
        if (document.selection) {
            var b_textRange = document.selection.createRange().duplicate();
            b_textRange.moveStart("character", -b_ctr.value.length);
            b_vtri = b_textRange.text.length;
        }
        else b_vtri = b_ctr.selectionStart;
        return b_vtri;
    }
    catch (ex) { return 0 }
}
//Dat lai vi tri con tro
function contro_dat(b_ctr, b_vtri) {
    try {
        if (b_vtri < 0 || b_vtri > b_ctr.value.length) return;
        if (document.selection) {
            var b_textRange = b_ctr.createTextRange();
            b_textRange.moveStart("character", b_vtri);
            b_textRange.moveEnd("character", b_vtri - b_ctr.value.length);
            b_textRange.select();
        }
        else if (b_ctr.selectionStart || b_ctr.selectionEnd == '0') { b_ctr.selectionStart = b_ctr.selectionEnd = b_vtri; }
    }
    catch (ex) { }
}
//Bo cac ky tu dang danh dau
function contro_P_boChon(b_ctr) {
    try {
        var b_s = b_ctr.value, b_d = 0, b_c = 0;
        if (document.selection) {
            b_c = contro_vtri(b_ctr);
            var b_textRange = document.selection.createRange();
            b_d = b_c - b_textRange.text.length;
        }
        else if (b_ctr.selectionStart || b_ctr.selectionStart == '0') {
            b_d = b_ctr.selectionStart; b_c = b_ctr.selectionEnd;
        }
        if (b_s != "" && b_d >= 0 && b_c > b_d) { b_ctr.value = b_s.substr(0, b_d) + b_s.substr(b_c); contro_dat(b_ctr, b_d); }
    }
    catch (ex) { }
}

//Dat Attribute
function form_Fb_CHAY() {
    try {
        if (form_chay == 1) return true;
        form_chay = 1; return false;
    }
    catch (ex) { return false; }
}

//Goi Form khi bam F1, chuot phai
function goiForm(b_ctr, event) {
    try {
        var b_f = C_NVL(b_ctr.getAttribute("f_tkhao")), b_s = C_NVL(b_ctr.getAttribute("f_sht_tkhao"));
        if (b_f == null || b_f == "") return;
        if (b_f.indexOf("aspx") > 0) {
            if (event.shiftKey && b_s != null && b_s != "") b_f = b_s;
            var b_guiId = C_NVL(b_ctr.getAttribute("guiId"));
            var b_gui = (b_guiId != "") ? $get(b_guiId).value : b_ctr.getAttribute("gui");
            if (C_NVL(b_gui) == "") b_gui = C_NVL(b_ctr.value);
            var a_tso = (b_gui != null && b_gui != "") ? ["THAMSO", [b_gui]] : null;

            var b_cot = b_ctr.getAttribute("col");
            if (b_cot != undefined && b_cot != null && b_cot != "") {
                a_tso = ["GUI_TS", [b_cot]];
            }
            form_P_MO(b_f, window.name + "," + b_ctr.id, a_tso);

        }
        else if (window.P_TSO_DAY != null && window.P_TSO_DAY != undefined) {
            if (event.shiftKey && b_s != null && b_s != "") b_f = b_s;
            window.P_TSO_DAY(b_f, event);
        }
    }
    catch (ex) { }
}
function sukien_Fn_keyPress(event) {
    try {
        var b_kq = (window.event) ? event.keyCode : event.charCode;
        return b_kq;
    }
    catch (err) { return -1; }
}
function sukien_P_keyPress(event, b_key) {
    try {
        if (window.event) event.keyCode = b_key;
        else {
            if (b_key <= 0) event.preventDefault ? event.preventDefault() : event.returnValue = false;
            else {
                var newEvent = document.createEvent("KeyEvents");
                newEvent.initKeyEvent("keypress", true, true, document.defaultView, event.ctrlKey, event.altKey, event.shiftKey, event.metaKey, 0, b_key);
                event.preventDefault ? event.preventDefault() : event.returnValue = false; event.target.dispatchEvent(newEvent);
            }
        }
    }
    catch (err) { form_P_LOI(err); }
}

//QuangNN (20/06/2014)
function Grid_Active(gridId) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var grid_editable = $("#" + gridId).attr("editable");

        if (grid_editable !== undefined && grid_editable !== null && grid_editable == 'false') {
            var b_rows = b_grid.dataSource.data();

            if (b_rows.length > 0) {
                Grid_ThoiActive(gridId);
                Grid_DatActiveRow(gridId, 0);
            }

            return;
        }

        var b_columns = b_grid.columns;
        var b_hang = 0;

        for (var b_icot = 0; b_icot < b_columns.length; b_icot++) {
            if (b_columns[b_icot].edit && !b_columns[b_icot].hidden) {
                Grid_ThoiActive(gridId);
                Grid_DatActiveRow(gridId, b_hang);
                Grid_EditCell(gridId, b_hang, b_icot);

                return;
            }
        }
    }
    catch (err) { }
}

//QuangNN (23/06/2014)
//Chuyen về control trước
function sukien_P_TRUOC(b_ctr) {
    try {
        var ctr_truoc = b_ctr.getAttribute("ctr_truoc");
        if (ctr_truoc != null && ctr_truoc != '') {
            var b_ctr = form_Fctr_VTEN_DTUONG("", ctr_truoc);

            if (C_NVL(b_ctr.style.display) != "none" && !b_ctr.disabled && C_NVL(b_ctr.style.visibility) != "hidden") {
                b_ctr.focus();
                return true;
            }
        }

        var grid_truoc = b_ctr.getAttribute("grid_truoc");
        if (grid_truoc != null && grid_truoc != '') {
            Grid_Active(form_Fs_Grid_ID("", grid_truoc));
            return true;
        }

        P_TRUOC(b_ctr);
    } catch (err) {
        form_P_LOI(err);
    }
}

function P_TRUOC(b_ctr) {
    var b_form = document.forms[0], b_vtri = 0, b_tim = -1;

    for (var i = b_form.elements.length - 1; i > 0; i--) {
        if (b_tim < 0 && b_form.elements[i].type != 'hidden' && b_form.elements[i].focus && C_NVL(b_form.elements[i].style.display) != "none" && !b_form.elements[i].disabled && C_NVL(b_form.elements[i].style.visibility) != "hidden") {
            b_tim = i;
        }

        if (b_ctr == b_form.elements[i]) {
            b_vtri = i - 1;
            break;
        }
    }

    for (var i = b_vtri; i >= 0; i--) {
        if (b_form.elements[i].type != 'hidden' && b_form.elements[i].focus && C_NVL(b_form.elements[i].style.display) != "none" && !b_form.elements[i].disabled && C_NVL(b_form.elements[i].style.visibility) != "hidden") {
            b_tim = i;
            break;
        }
    }

    if (b_tim >= 0)
        b_form.elements[b_tim].focus();
}

//QuangNN (20/06/2014)
//Chuyen sang control tiep theo
function sukien_P_TIEP(b_ctr) {
    try {

        var ctr_sau = b_ctr.getAttribute("ctr_sau");
        if (ctr_sau != null && ctr_sau != '') {
            var b_ctr = form_Fctr_VTEN_DTUONG("", ctr_sau);

            if (C_NVL(b_ctr.style.display) != "none" && !b_ctr.disabled && C_NVL(b_ctr.style.visibility) != "hidden") {
                b_ctr.focus();
                return true;
            }
        }

        var grid_sau = b_ctr.getAttribute("grid_sau");
        if (grid_sau != null && grid_sau != '') {
            Grid_Active(form_Fs_Grid_ID("", grid_sau));
            return true;
        }

        P_TIEP(b_ctr);
    } catch (err) {
        form_P_LOI(err);
    }
}

function P_TIEP(b_ctr) {
    var b_form = document.forms[0], b_vtri = 0, b_tim = -1;

    for (var i = 0; i < b_form.elements.length - 1; i++) {
        if (b_tim < 0 && b_form.elements[i].type != 'hidden' && b_form.elements[i].focus && C_NVL(b_form.elements[i].style.display) != "none" && !b_form.elements[i].disabled && C_NVL(b_form.elements[i].style.visibility) != "hidden") {
            b_tim = i;
        }

        if (b_ctr == b_form.elements[i]) {
            b_vtri = i + 1;
            break;
        }
    }

    for (var i = b_vtri; i < b_form.elements.length; i++) {
        if (b_form.elements[i].type != 'hidden' && b_form.elements[i].focus && C_NVL(b_form.elements[i].style.display) != "none" && !b_form.elements[i].disabled && C_NVL(b_form.elements[i].style.visibility) != "hidden") {
            b_tim = i;
            break;
        }
    }

    if (b_tim >= 0)
        b_form.elements[b_tim].focus();
}

//Xu ly bam chuot
function chuot(b_ctr, event) {
    if (event.button == 2) goiForm(b_ctr, event);
}

//QuangNN (26/05/2014) - Chua sua xong
//Grid - KeyUp
function Grid_len(gridId, event) {
    try {
        alert("Grid_len");
        event.preventDefault ? event.preventDefault() : event.returnValue = false;
        event = event || window.event;

        var key = event.keyCode;
        var b_grid = $("#" + gridId).data("kendoGrid");

        if (!event.ctrlKey) {
            if (key == 33 || key == 34) {
                var b_slideId = gridId + "_slide";
                if ($get(b_slideId + "_an") != null) {
                    var b_dk = (key == 33) ? "T" : "P";
                    slide_P_CHUYEN(b_slideId, b_dk);
                }
            }
            return;
        }
        //Phan tren da OK

        //if (key == 33 || key == 34 || key == 35 || key == 36) {
        //    var b_cot = Grid_Fs_cotTt(gridId);
        //    if (b_cot == "") return;
        //    var b_div = b_grid.DivElement;
        //    if (b_div.onscroll != null && b_div.onscroll != undefined) {
        //        if (key == 33 || key == 36) Grid_P_DatGtri(gridId, 0, b_cot, -1);
        //        else Grid_P_DatGtri(gridId, 0, b_cot, -2);
        //        b_div.onscroll();
        //    }
        //    return;
        //}

        //if (key != 9) return;
        //var b_ctrId = b_grid.ClientID + "_ctr_chuyen";
        //var b_ctr = $get(b_ctrId);
        //if (b_ctr == null) return;
        //var a_ten = b_ctr.value.split(",");
        //if (a_ten.length < 2) return;
        //var b_ten = (event.shiftKey) ? a_ten[0] : a_ten[1];
        //if (b_ten.indexOf("+") < 0) Grid_ThoiActive(gridId);
        //else b_ten = b_ten.replace('+', '');
        //if (b_ten.indexOf(":") < 0) $get(b_ten).focus();
        //else {
        //    a_ten = b_ten.split(":");
        //    b_grid = igtbl_getGridById(a_ten[0]);
        //    var b_row = b_grid.Rows.getRow(0);
        //    var b_cell = b_row.getCellFromKey(a_ten[1]);
        //    b_grid.setActiveCell(b_cell, true);
        //}
    }
    catch (ex) { }
}

//QuangNN (26/05/2014)
//Grid - Keydown
function Grid_xuong(gridId, event) {
    try {
        var b_key = event.keyCode;

        if (event.ctrlKey && (b_key == 65 || b_key == 67)) {
            return true;
        }

        var b_grid = $("#" + gridId).data("kendoGrid");
        var grid_editable = $("#" + gridId).attr("editable");
        var b_rows = b_grid.dataSource.data();
        var b_hang = b_grid.ROW_SELECTED_INDEX;
        var b_icot = b_grid.COL_SELECTED_INDEX;

        if (grid_editable !== undefined && grid_editable !== null && grid_editable == 'false') {
            switch (b_key) {
                //Trên
                case 38:
                    if (b_hang > 0) {
                        Grid_CloseCell(gridId, b_hang, b_icot);

                        Grid_DatActiveRow(gridId, b_hang - 1);
                        Grid_EditCell(gridId, b_hang - 1, b_icot);
                    }

                    event.preventDefault ? event.preventDefault() : event.returnValue = false;
                    return false;

                //Dưới
                case 40:
                    var currentPage = b_grid.dataSource.page();

                    var recordCount = 0;

                    if (currentPage === undefined) {
                        recordCount = b_rows.length;
                    }
                    else {
                        var page_size = b_grid.dataSource.pageSize();

                        if (currentPage * page_size <= b_rows.length) {
                            recordCount = page_size;
                        }
                        else {
                            recordCount = page_size - (currentPage * page_size - b_rows.length);
                        }
                    }

                    if (b_hang < recordCount - 1) {
                        Grid_CloseCell(gridId, b_hang, b_icot);

                        Grid_DatActiveRow(gridId, b_hang + 1);
                        Grid_EditCell(gridId, b_hang + 1, b_icot);
                    }

                    event.preventDefault ? event.preventDefault() : event.returnValue = false;
                    return false;

                //Page Up - Lùi về trang trước
                case 33:
                    Grid_To_Previous_Page(gridId);

                    event.preventDefault ? event.preventDefault() : event.returnValue = false;
                    return false;

                //Page Down - Tới trang sau
                case 34:
                    Grid_To_Next_Page(gridId);

                    event.preventDefault ? event.preventDefault() : event.returnValue = false;
                    return false;

                //End - Tới trang cuối
                case 35:
                    Grid_To_Last_Page(gridId);

                    event.preventDefault ? event.preventDefault() : event.returnValue = false;
                    return false;

                //Home - Tới trang đầu
                case 36:
                    Grid_To_First_Page(gridId);

                    event.preventDefault ? event.preventDefault() : event.returnValue = false;
                    return false;

                default:
                    event.preventDefault ? event.preventDefault() : event.returnValue = false;
                    return false;
            }
        }
        else {
            var b_columns = b_grid.columns;

            //if (event.ctrlKey && b_key == 86) {
            //    Grid_PasteFromExcel(gridId, event);
            //    return false;
            //}

            if (b_key == 13 || (!b_columns[b_icot].edit)) {
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;
            }
        }

        return true;
    }
    catch (ex) { return true; }
}

//function Grid_CopyToExcel(gridId, b_ctr, b_event) {
//    try {
//        var text;
//        var clp = (b_event.originalEvent || b_event).clipboardData;

//        if (clp === undefined || clp === null) {
//            window.clipboardData.setData("text", "Quang");
//        } else {
//            clp.setData('text/plain', "Quang");
//        }
//    }
//    catch (ex) { alert(ex.message); }
//}

function Grid_PasteFromExcel(gridId, b_ctr, b_event) {
    try {
        debugger;
        var text;
        var clp = (b_event.originalEvent || b_event).clipboardData;

        if (clp === undefined || clp === null) {
            text = window.clipboardData.getData("text") || "";
        } else {
            text = clp.getData('text/plain') || "";
        }

        text = text.trimEnd();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_columns = b_grid.columns;
        var dataRows = [];

        if (text.indexOf("\r\n") >= 0) {
            dataRows = text.split("\r\n");
        }
        else {
            dataRows = text.split("\n");
        }

        var b_hang = b_grid.ROW_SELECTED_INDEX;

        for (var i = 0; i < dataRows.length; i++) {
            var dataCells = dataRows[i].split("\t");

            var b_icot = b_grid.COL_SELECTED_INDEX;
            var j = 0;

            while (b_icot < b_columns.length && j < dataCells.length) {
                if (b_columns[b_icot].edit) {
                    var b_cot = b_columns[b_icot].field;

                    if (b_rows[b_hang] == null) {
                        var newRow = Grid_CreateNewRow(gridId);
                        b_rows.push(newRow);
                    }

                    //chan XSS bang cach chan cac the html ko cho nhap vao luoi
                    b_rows[b_hang][b_cot] = stripHtml(dataCells[j]);
                    //b_rows[b_hang][b_cot] = dataCells[j];

                    j++;
                }

                b_icot++;
            }

            b_hang++;
        }

        b_grid.refresh();
    }
    catch (ex) { }
}

//Loc gia tri, loai bo cac html tag: https://stackoverflow.com/questions/822452/strip-html-from-text-javascript
function stripHtml(html) {
    var tmp = document.createElement("DIV");
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || "";
}

//QuangNN (11/06/2014)
//Xu ly phim dang an xuong - Keydown
function xuong1(b_ctr, event) {
    try {
        var b_key = event.keyCode;
        var gridId = b_ctr.getAttribute("gridId");

        if (event.shiftKey) {
            if (b_key == 9) {
                sukien_P_TRUOC(b_ctr);
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;
            }

            if (b_key == 13) {
                Grid_CustomEditor_Change_Huong(b_ctr, gridId, b_ctr.name, 'PREVIOUS');
            }

            return true;
        }

        switch (b_key) {
            //Delete
            case 46:
                contro_P_boChon(b_ctr);
                break;

            //Tab
            case 9:
                //Grid_CustomEditor_change(b_ctr, gridId, b_ctr.name, true);
                sukien_P_TIEP(b_ctr);
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;

            //Enter
            case 13:
                Grid_CustomEditor_change(b_ctr, gridId, b_ctr.name, true);
                break;

            //Trái
            case 37:
                Grid_CustomEditor_Change_Huong(b_ctr, gridId, b_ctr.name, 'L');
                break;

            //Trên
            case 38:
                Grid_CustomEditor_Change_Huong(b_ctr, gridId, b_ctr.name, 'U');
                break;

            //Phải
            case 39:
                Grid_CustomEditor_Change_Huong(b_ctr, gridId, b_ctr.name, 'R');
                break;

            //Dưới
            case 40:
                Grid_CustomEditor_Change_Huong(b_ctr, gridId, b_ctr.name, 'D');
                break;

            //F1
            case 112:
                document.onhelp = new Function("return false;");
                if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }

                goiForm(b_ctr, event);
                break;
        }
    }
    catch (err) { form_P_LOI(err); }
}

//QuangNN (11/06/2014)
//Xu ly phim dang an xuong - Keydown
function xuong(b_ctr, event) {
    try {
        // b_key = event.keyCode;
        //debugger;
        var b_key = Lib.Common.getKeyCode(event);
        if (event.shiftKey) {
            if (b_key == 9) {
                sukien_P_TRUOC(b_ctr);
                if (C_NVL(b_ctr.getAttribute("Tchange")) == "C" && b_ctr.onchange) b_ctr.onchange();
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;
            }

            if (b_key == 112) {
                document.onhelp = new Function("return false;");
                if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }
                goiForm(b_ctr, event);
            }

            return;
        }

        switch (b_key) {
            case 46: contro_P_boChon(b_ctr); break;

            case 9://Tab
            case 13://Enter
            case 40://Down
                sukien_P_TIEP(b_ctr);
                if (C_NVL(b_ctr.getAttribute("Tchange")) == "C" && b_ctr.onchange) b_ctr.onchange();
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;

            case 38://Up
                sukien_P_TRUOC(b_ctr);
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;

            case 112:
                document.onhelp = new Function("return false;");
                if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }

                goiForm(b_ctr, event);
                break;
        }
    }
    catch (err) { form_P_LOI(err); }
}

//QuangNN (23/06/2014)
//Xu ly phim dang an xuong - Keydown
function button_xuong(b_ctr, event) {
    try {
        //b_key = event.keyCode;
        var b_key = Lib.Common.getKeyCode(event);

        //Shift Tab
        if (event.shiftKey) {
            if (b_key == 9) {
                sukien_P_TRUOC(b_ctr);

                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;
            }

            return;
        }

        switch (b_key) {
            case 9://Tab
            case 40://Down
                sukien_P_TIEP(b_ctr);
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;

            case 38://Up
                sukien_P_TRUOC(b_ctr);
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;
        }
    }
    catch (err) { form_P_LOI(err); }
}

//QuangNN (20/06/2014)
//So - Keydown
function so_xuong(b_ctr, event) {
    try {
        //b_key = event.keyCode;
        var b_key = Lib.Common.getKeyCode(event);
        if (event.shiftKey) {
            if (b_key == 9) {
                so_doi(b_ctr);

                if (C_NVL(b_ctr.getAttribute("Tchange")) == "C" && b_ctr.onchange) b_ctr.onchange();

                sukien_P_TRUOC(b_ctr);

                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;
            }

            if (b_key == 112) {
                document.onhelp = new Function("return false;");
                if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }
                goiForm(b_ctr, event);
            }

            return;
        }

        switch (b_key) {
            case 46: contro_P_boChon(b_ctr); Attribute_P_DAT(b_ctr, "Tchange", "C"); break;

            case 9: //Tab
            case 13: //Enter
            case 40: //Down
                so_doi(b_ctr);

                if (C_NVL(b_ctr.getAttribute("Tchange")) == "C" && b_ctr.onchange) b_ctr.onchange();

                sukien_P_TIEP(b_ctr);

                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;

            case 38://Up
                so_doi(b_ctr);

                if (C_NVL(b_ctr.getAttribute("Tchange")) == "C" && b_ctr.onchange) b_ctr.onchange();

                sukien_P_TRUOC(b_ctr);

                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;

            case 112:
                document.onhelp = new Function("return false;");
                if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }

                goiForm(b_ctr, event);
                break;

            default: so_doi(b_ctr); break;
        }
    }
    catch (err) { form_P_LOI(err); }
}
//dong - Keydown
function dong_xuong(b_ctr, event) {
    try {
        //var b_key = event.keyCode;
        var b_key = Lib.Common.getKeyCode(event);

        switch (event.keyCode) {
            case 46: contro_P_boChon(b_ctr); break;
            case 9: break;
            case 13: b_key = 9; break;
            case 40: b_key = 9; break;
            case 112:
                document.onhelp = new Function("return false;");
                if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }

                goiForm(b_ctr, event);
                break;
            default: dong_doi(b_ctr); break;
        }
        if (b_key == 9 && event.keyCode != 9) {
            if (window.event) event.keyCode = 9;
            else { sukien_P_TIEP(b_ctr); return false; }
        }
    }
    catch (ex) { }
}

//QuangNN (20/06/2014)
//Ngay - Keydown
function ngay_xuong(b_ctr, event) {
    try {
        //var b_key = event.keyCode;
        var b_key = Lib.Common.getKeyCode(event);
        if (event.shiftKey) {
            if (b_key == 9) {
                ngay_doi(b_ctr);
                if (C_NVL(b_ctr.getAttribute("Tchange")) == "C" && b_ctr.onchange) b_ctr.onchange();
                sukien_P_TRUOC(b_ctr);

                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;
            }

            if (b_key == 112) {
                document.onhelp = new Function("return false;");
                if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }
                goiForm(b_ctr, event);
            }

            return;
        }

        switch (b_key) {
            case 9: //Tab
            case 13: //Enter
            case 40: //Down
                ngay_doi(b_ctr);
                if (C_NVL(b_ctr.getAttribute("Tchange")) == "C" && b_ctr.onchange) b_ctr.onchange();
                sukien_P_TIEP(b_ctr);

                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;

            case 38://Up
                ngay_doi(b_ctr);

                if (C_NVL(b_ctr.getAttribute("Tchange")) == "C" && b_ctr.onchange) b_ctr.onchange();

                sukien_P_TRUOC(b_ctr);

                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;

            case 112:
                document.onhelp = new Function("return false;");
                if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }

                goiForm(b_ctr, event);
                break;
            default: ngay_doi(b_ctr); break;
        }
    }
    catch (ex) { }
}

//QuangNN (20/06/2014)
//Xu ly phim dang an xuong - Keydown
function xuong_drop(b_ctr, event) {
    //var b_key = event.keyCode;
    var b_key = Lib.Common.getKeyCode(event);
    if (event.shiftKey) {
        if (b_key == 9) {
            sukien_P_TRUOC(b_ctr);

            event.preventDefault ? event.preventDefault() : event.returnValue = false;
            return false;
        }

        return;
    }

    switch (b_key) {
        case 9: //Tab
        case 13: //Enter
            sukien_P_TIEP(b_ctr);
            event.preventDefault ? event.preventDefault() : event.returnValue = false;
            return false;

        case 38://Up
            sukien_P_TRUOC(b_ctr);
            event.preventDefault ? event.preventDefault() : event.returnValue = false;
            return false;

        case 112:
            document.onhelp = new Function("return false;");
            if (navigator.userAgent.search(/msie/i) == -1) { event.stopPropagation(); event.preventDefault(); }

            goiForm(b_ctr, event);
            break;
    }
}
//Xu ly phim ma an - KeyPress
function ma_an(b_ctr, event) {
    try {
        var b_key = sukien_Fn_keyPress(event);
        if (b_key <= 0) return;
        if (event.ctrlKey) return;
        var b_s = String.fromCharCode(b_key);
        contro_P_boChon(b_ctr);
        if (C_NVL(b_ctr.getAttribute("kieu_so")) == "C") {
            // debugger;
            if ("0123456789".indexOf(b_s) < 0) { sukien_P_keyPress(event, 0); return false };
        }
        else if (C_NVL(b_ctr.getAttribute("lke")) != "") {
            kieu_click(b_ctr);
        }
        else if (C_NVL(b_ctr.getAttribute("kieu_chu")) == "C") {
            if (b_s != b_s.toUpperCase()) {
                b_key = b_s.toUpperCase().charCodeAt(0);
                var postion = contro_vtri(b_ctr);
                var val = b_ctr.value.toString().substring(0, postion) +
                    b_s.toUpperCase() + b_ctr.value.toString().substring(postion);
                contro_dat(b_ctr, postion + 1);
                Attribute_P_DAT(b_ctr, "Tchange", "C")
                sukien_P_keyPress(event, b_key);
                if (val.length > b_ctr.getAttribute("MaxLength") && b_ctr.getAttribute("MaxLength") > 0) {
                    event.preventDefault ? event.preventDefault() : event.returnValue = false; return false;
                }
                b_ctr.value = val;
                event.preventDefault ? event.preventDefault() : event.returnValue = false;
                return false;
            }
        }
    }
    catch (err) { form_P_LOI(err); }
}
//So - Key press
function so_an(b_ctr, event) {
    try {
        var b_key = sukien_Fn_keyPress(event);
        if (b_key <= 0) return;
        if (event.ctrlKey) return;
        contro_P_boChon(b_ctr); sukien_P_keyPress(event, 0);
        var b_s = String.fromCharCode(b_key), b_cu = b_ctr.value, b_ktra = "0123456789", b_so_tp = CSO_SO(b_ctr.getAttribute("so_tp"), 0);
        if (C_NVL(b_ctr.getAttribute("co_dau")) == "C") b_ktra = b_ktra + "-";
        if (b_so_tp > 0) b_ktra = b_ktra + ".";
        if (b_ktra.indexOf(b_s) < 0 || (b_s == "0" && b_cu == "0") || (b_s == "-" && b_cu.indexOf("-") >= 0) || (b_s == "." && b_cu.indexOf(".") >= 0)) { event.preventDefault ? event.preventDefault() : event.returnValue = false; return false; }

        var b_vtri = contro_vtri(b_ctr), b_moi, b_cuoi;
        if (b_vtri < b_cu.length) b_cuoi = "K"; else b_cuoi = "C";
        b_cu = b_cu.substr(0, b_vtri) + b_s + b_cu.substr(b_vtri);
        b_vtri += 1;
        b_moi = CH_CSO(b_cu, b_so_tp);
        if (b_cuoi == "C") b_vtri = b_moi.length;
        else {
            if (b_moi.length > b_cu.length) b_vtri += 1;
            if (b_moi.substr(b_vtri, 1) == ",") b_vtri += 1;
        }
        b_ctr.value = b_moi;
        contro_dat(b_ctr, b_vtri); Attribute_P_DAT(b_ctr, "Tchange", "C");
        event.preventDefault ? event.preventDefault() : event.returnValue = false;
        return false;
    }
    catch (err) { form_P_LOI(err); }
}
//Ngay - Key press
function ngay_an(b_ctr, event) {
    try {
        var b_key = sukien_Fn_keyPress(event);
        if (b_key <= 0) return;
        if (event.ctrlKey) return;
        sukien_P_keyPress(event, 0);
        var b_s = String.fromCharCode(b_key), b_cu = b_ctr.value;
        if ("0123456789".indexOf(b_s) < 0) { Attribute_P_DAT(b_ctr, "Tchange", "C"); event.preventDefault ? event.preventDefault() : event.returnValue = false; return false; }
        var b_vtri = contro_vtri(b_ctr), b_moi, b_cuoi;
        if (b_vtri < b_cu.length) b_cuoi = "K"; else b_cuoi = "C";
        b_cu = b_cu.substr(0, b_vtri) + b_s + b_cu.substr(b_vtri + 1);
        b_vtri += 1;
        b_moi = CH_CNG(b_cu);
        if (b_moi.substr(b_vtri, 1) == "/") b_vtri += 1;
        b_ctr.value = b_moi;
        contro_dat(b_ctr, b_vtri); Attribute_P_DAT(b_ctr, "Tchange", "C");
        event.preventDefault ? event.preventDefault() : event.returnValue = false;
        return false;
    }
    catch (ex) { }
}
//KIEU - An
function kieu_an(b_ctr, event) {
    try {
        var b_lke = C_NVL(b_ctr.getAttribute("lke"));
        if (b_lke == "") return;
        //Neu su dung kieu voi lke nhieu ky tu, vi du 2.1   (lke="1,2.1,2.2" thay vi lke="1,2,3") thi dung ham rieng de co the go tay 2.1
        if (IsLKeNhieuKyTu(b_lke))
            return kieu_an_nhieu_ky_tu(b_ctr, event);

        var b_key = sukien_Fn_keyPress(event);
        if (b_key <= 0) return;
        if (event.ctrlKey) return;
        sukien_P_keyPress(event, 0);
        var b_s = String.fromCharCode(b_key);

        if (Fb_MA_MA_D(b_lke, b_s)) {
            var b_cu = b_ctr.value, b_moi = "", b_icu = 0, a_s = b_lke.split(',');
            for (var i = 0; i < a_s.length; i++)
                if (a_s[i] == b_cu) { b_icu = i; break; }
            b_ctr.value = b_cu = a_s[b_icu]; b_s = b_s.toUpperCase();
            while (b_moi == "") {
                b_icu++;
                if (b_icu >= a_s.length) b_icu = 0;
                if (a_s[b_icu].substr(0, 1).toUpperCase() == b_s) { b_moi = a_s[b_icu]; break; }
            }
            b_ctr.value = b_moi; contro_dat(b_ctr, 0);
            if (b_ctr.onchange) b_ctr.onchange();
        }
        event.preventDefault ? event.preventDefault() : event.returnValue = false;
        return false;
    }
    catch (ex) { }
}
function kieu_an_nhieu_ky_tu(b_ctr, event) {
    try {
        var b_key = sukien_Fn_keyPress(event);
        if (b_key <= 0) return;
        if (event.ctrlKey) return;
        sukien_P_keyPress(event, 0);
        var b_s = String.fromCharCode(b_key);
        var b_value = b_ctr.value + b_s.toUpperCase();
        var b_lke = C_NVL(b_ctr.getAttribute("lke"));
        if (b_lke == "") return;
        if (Fb_MA_MA_D(b_lke, b_value)) {
            b_ctr.value = b_value;
        }
        /*if (Fb_MA_MA_D_kieu(b_lke, b_value) == 1) {
            b_ctr.value = b_value; //contro_dat(b_ctr, 0);
            //if (b_ctr.onchange) b_ctr.onchange();
        }
        else if (Fb_MA_MA_D_kieu(b_lke, b_value) == 2) {
            b_ctr.value = b_value;
        }*/
        event.preventDefault ? event.preventDefault() : event.returnValue = false;
        return false;
    }
    catch (ex) { }
}
function IsLKeNhieuKyTu(b_lke) {
    var b_lke_ct = b_lke.split(',');
    for (var i = 0; i < b_lke_ct.length; i++)
        if (b_lke_ct[i].length > 1) return true;
    return false;
}
//Dong - Key press
function dong_an(b_ctr, event) {
    try {
        var b_dateVar = new Date();
        var b_datenam = b_dateVar.getFullYear();
        //if (b_datenam < 2000 || b_datenam > 2000 + 10 + 2) return;
        var b_kieu = C_NVL(b_ctr.getAttribute("kieu"));
        if (b_kieu == "C") return;
        var b_key = sukien_Fn_keyPress(event);
        if (b_key <= 0) return;
        if (event.ctrlKey) return;
        var b_s = String.fromCharCode(b_key), b_cu = b_ctr.value;
        if (b_kieu == "H") {
            if (b_s != b_s.toUpperCase()) {
                b_key = b_s.toUpperCase().charCodeAt(0);
                sukien_P_keyPress(event, b_key);
            }
            return;
        }
        sukien_P_keyPress(event, 0);
        if (b_kieu == "S") {
            if ("0123456789.-".indexOf(b_s) < 0 ||
                (b_s == "0" && b_cu == "0") ||
                (b_s == "-" && b_cu.indexOf("-") >= 0) ||
                (b_s == "." && b_cu.indexOf(".") >= 0)) b_key = 0;
        }
        else if (b_kieu == "N") {
            if ("0123456789".indexOf(b_s) < 0) b_key = 0;
        }
        if (b_key == 0) return;
        var b_vtri = contro_vtri(b_ctr), b_moi, b_cuoi;
        if (b_vtri < b_cu.length) b_cuoi = "K"; else b_cuoi = "C";
        if (b_kieu == "N")
            b_cu = b_cu.substr(0, b_vtri) + b_s + b_cu.substr(b_vtri + 1);
        else b_cu = b_cu.substr(0, b_vtri) + b_s + b_cu.substr(b_vtri);
        b_vtri += 1;
        if (b_kieu == "S") {
            b_moi = CH_CSO(b_cu, 8);
            if (b_cuoi == "C") b_vtri = b_moi.length;
            else {
                if (b_moi.length > b_cu.length) b_vtri++;
                if (b_moi.substr(b_vtri, 1) == ",") b_vtri++;
            }
        }
        else {
            b_moi = CH_CNG(b_cu);
            if (b_moi.substr(b_vtri, 1) == "/") b_vtri++;
        }
        b_ctr.value = b_moi;
        contro_dat(b_ctr, b_vtri);
    }
    catch (ex) { }
} //Xu ly khi thay doi lua chon
function chon_drop(b_ctr, b_title) {
    try {
        var b_s = (b_title) ? b_title + ": " : "";
        b_ctr.title = b_s + b_ctr.options[b_ctr.selectedIndex].text;
    }
    catch (ex) { }
}
//KIEU - Click
function kieu_click(b_ctr) {
    try {
        if (b_ctr != null) {
            b_ctr.value = F_DAO(b_ctr.value, C_NVL(b_ctr.getAttribute("lke")));

            if (b_ctr.onchange) b_ctr.onchange();
        }
    }
    catch (ex) { }
}
//NHAN - Click
function nhan_click(b_ctr) {
    try { kieu_click(b_ctr); goiForm(b_ctr, event); }
    catch (ex) { }
}
//NHOM - Click
function nhom_click(b_ctr) {
    try {
        var b_lke = C_NVL(b_ctr.getAttribute("lke"));
        if (b_lke == "") return;
        var a_lke = b_lke.split(',')
        var b_i = Fi_vtri_mang(a_lke, b_ctr.value) + 1;
        if (b_i >= a_lke.length) b_i = 0;
        b_ctr.value = a_lke[b_i];
        nhom_cthich(b_ctr);
        b_ctr.focus();
        if (b_ctr.onchange) b_ctr.onchange();
    }
    catch (ex) { }
}
function nhom_cthich(b_ctr) {
    try {
        var b_lke = C_NVL(b_ctr.getAttribute("lke")), b_gchuId = C_NVL(b_ctr.getAttribute("gchu")), b_cthich = C_NVL(b_ctr.getAttribute("cthich"));
        if (b_gchuId == "" || b_lke == "" || b_cthich == "") return;
        var a_lke = b_lke.split(','), a_gchu = b_cthich(',');
        var b_gchu = Fobj_gtri_mang(a_lke, a_gchu, b_ctr.value);
        form_P_DatGchu(b_gchuId, b_gchu);
    }
    catch (ex) { }
}
//NHOM - key press
function nhom_an(b_ctr, event) {
    try { sukien_P_keyPress(event, 0); nhom_click(b_ctr); }
    catch (ex) { }
}
//So - onchange
function so_doi(b_ctr) {
    try {
        var b_cu = b_ctr.value, b_so_tp = CSO_SO(b_ctr.getAttribute("so_tp"), 0);
        var b_moi = CH_CSO(b_cu, b_so_tp);
        if (b_moi == b_cu) return;
        var b_vtri = contro_vtri(b_ctr);
        b_cu = b_moi.substr(b_vtri, 1);
        b_ctr.value = b_moi;
        if (b_cu == ",") b_vtri++;
        contro_dat(b_ctr, b_vtri); Attribute_P_DAT(b_ctr, "Tchange", "C");
    }
    catch (ex) { }
}
//Ngay - onchange
function ngay_doi(b_ctr) {
    try {
        var b_cu = b_ctr.value, b_moi = CH_CNG(b_cu);
        if (b_moi == b_cu) return;
        var b_vtri = contro_vtri(b_ctr);
        b_cu = b_moi.substr(b_vtri, 1);
        b_ctr.value = b_moi;
        if (b_cu == "/") b_vtri++;
        contro_dat(b_ctr, b_vtri); Attribute_P_DAT(b_ctr, "Tchange", "C");
    }
    catch (ex) { }
}
//Text box dong - onchange
function dong_doi(b_ctr) {
    try {
        var b_kieu = b_ctr.getAttribute("kieu");
        if (b_kieu == "C") return;
        var b_cu = b_ctr.value, b_moi;
        if (b_kieu == "H") { b_ctr.value = b_cu.toUpperCase(); return; }
        if (b_kieu == "S") b_moi = CH_CSO(b_cu, 8);
        else if (b_kieu == "N") b_moi = CH_CNG(b_cu);
        if (b_moi == b_cu) return;
        var b_vtri = contro_vtri(b_ctr);
        b_cu = b_moi.substr(b_vtri, 1);
        b_ctr.value = b_moi;
        if (b_cu == "/" || b_cu == ",") contro_dat(b_ctr, b_vtri + 1);
    }
    catch (ex) { }
}

function CH_CSO(b_chu, b_so_tp) {
    try {
        if (b_chu == null || b_chu == "") return "";
        var b_moi = "", b_chan = "", b_tp = "", b_dau = "", b_cham = "", b_s, i;
        for (i = 0; i < b_chu.length; i++) {
            b_s = b_chu.substr(i, 1);
            if (b_s == ".") b_cham = ".";
            else if (b_s == "-") b_dau = "-";
            else if ("0123456789".indexOf(b_s) >= 0) {
                if (b_cham == ".") b_tp = b_tp + b_s;
                else if (b_chan == "0") b_chan = b_s;
                else b_chan = b_chan + b_s;
            }
        }
        if (b_chan.length > 3) {
            while (b_chan != "") {
                i = b_chan.length - 3;
                if (i < 0) i = 0;
                if (b_moi != "") b_moi = b_chan.substr(i) + "," + b_moi;
                else b_moi = b_chan.substr(i);
                if (i == 0) b_chan = ""; else b_chan = b_chan.substr(0, i);
            }
        }
        else b_moi = b_chan;
        if (b_so_tp != null)
            if (b_so_tp > 0 && b_tp.length > b_so_tp) b_tp = b_tp.substr(0, b_so_tp);
        b_moi = b_dau + b_moi + b_cham + b_tp;
        return b_moi;
    }
    catch (ex) { return b_chu; }
}
function CSO_SO(b_chu, b_so_tp) {
    try {
        b_chu = b_chu.toString();
        b_chu = CH_CSO(b_chu, b_so_tp);
        if (b_chu == "") return 0;
        while (b_chu.indexOf(',') >= 0) b_chu = b_chu.replace(',', '');
        return b_chu * 1.0;
    }
    catch (ex) { return 0; }
}
function SO_CSO(b_so, b_so_tp) {
    if (b_so == null) return "0";
    return CH_CSO(b_so.toString(), b_so_tp)
}
function CH_CNG(b_chu) {
    try {
        if (b_chu == "") return "";
        var b_moi = "", b_s, i;
        for (i = 0; i < b_chu.length; i++) {
            b_s = b_chu.substr(i, 1);
            if ("0123456789".indexOf(b_s) >= 0) b_moi = b_moi + b_s;
        }
        if (b_moi == "") return "";
        b_moi = b_moi + "          ";
        b_moi = b_moi.substr(0, 2) + "/" + b_moi.substr(2, 2) + "/" + b_moi.substr(4, 4);
        return b_moi;
    }
    catch (ex) { return b_chu; }
}
function CNG_CSO(b_chu) {
    if (Fb_NGAY_TRANG(b_chu)) b_chu = "01/01/3000";
    var b_loi = Fs_NGAY_LOI(b_chu, "K");
    if (b_loi != "") return "0";
    else return b_chu.substr(6, 4) + b_chu.substr(3, 2) + b_chu.substr(0, 2);
}
function CNG_SO(b_chu) {
    var b_moi = CNG_CSO(b_chu);
    return b_moi * 1.0;
}
function CSO_CNG(b_chu) {
    return b_chu.substr(6, 2) + "/" + b_chu.substr(4, 2) + "/" + b_chu.substr(0, 4);
}
function SO_CNG(b_so) {
    return CSO_CNG(b_so.toString())
}
// Chuyen chu dang dd/mm/yyyy sang dang date
function CNG_NG(b_ngay) {
    if (Fb_NGAY_TRANG(b_ngay)) b_ngay = "01/01/3000";
    var b_d = parseInt(b_ngay.substr(0, 2), 10), b_m = parseInt(b_ngay.substr(3, 2) - 1, 10), b_y = parseInt(b_ngay.substr(6, 4), 10);
    var b_kq = new Date(b_y, b_m, b_d);
    return b_kq;
}
// Chuyen date sang chu dang dd/mm/yyyy
function NG_CNG(b_ngay) {
    var b_ng = b_ngay.getDate().toString(), b_th = (b_ngay.getMonth() + 1).toString();
    if (b_ng.length < 2) b_ng = "0" + b_ng;
    if (b_th.length < 2) b_th = "0" + b_th;
    return b_ng + '/' + b_th + '/' + b_ngay.getFullYear().toString();
}
// So ngay trong thang
function Fi_NGAY_THANG(b_m, b_y) {
    var b_d = 31, b_m_c = b_m.toString();
    if (Fb_MA_MA("4,6,9,11", b_m_c)) b_d = 30;
    else if (b_m == 2) b_d = (ROUNDN(b_y / 4, 1) == ROUNDN(b_y / 4, 0)) ? 29 : 28;
    return b_d;
}
// Tang ngay len 1 so thang
function Fs_NGAY_THANG(b_ngay, b_thang) {
    var b_date = CNG_NG(b_ngay);
    var b_nam = b_date.getFullYear();
    b_thang += b_date.getMonth();
    if (b_thang > 0) {
        while (b_thang > 11) { b_nam++; b_thang -= 12; }
    }
    else if (b_thang < 0) {
        while (b_thang < 0) { b_nam--; b_thang += 12; }
    }
    b_date.setMonth(b_thang); b_date.setYear(b_nam);
    if (b_thang < b_date.getMonth()) {
        var b_ngay_m = Fi_NGAY_THANG(b_thang + 1, b_nam);
        b_date.setDate(1); b_date.setMonth(b_thang); b_date.setDate(b_ngay_m);
    }
    return NG_CNG(b_date);
}
// Tang ngay len 1 so nam
function Fs_NGAY_NAM(b_ngay, b_nam) {
    var b_thang = b_nam * 12;
    return Fs_NGAY_THANG(b_ngay, b_thang);
}

//Loc ky tu trang
function C_NVL(b_in) {
    var b_kq = (b_in == null || b_in == undefined) ? "" : b_in.toString().replace(/^[\s]+/, '').replace(/[\s]+$/, '').replace(/[\s]{2,}/, ' ');
    if (b_kq.toUpperCase() == "NULL") b_kq = "";
    return b_kq;
}
//Loc ky ky tu trang. Neu b_in ="" tra b_out
function O_NVL(b_in, b_out) { // Dan
    b_in = C_NVL(b_in);
    return (b_in == "") ? b_out : b_in;
}
//Lọc ký tự trắng bên phải
function R_NVL(b_in) { // Dan
    return (b_in == null) ? "" : b_in.replace(/\s+$/, "");
}
//Ngay - Kiem tra ngay trang
function Fb_NGAY_TRANG(b_ngay) {
    if (b_ngay == null) return true;
    while (b_ngay.indexOf('/') >= 0) b_ngay = b_ngay.replace('/', '');
    b_ngay = C_NVL(b_ngay);
    return (b_ngay == "");
}
//Ngay - Kiem tra nhap
function Fs_NGAY_LOI(b_ngay, b_kieu) {
    if (Fb_NGAY_TRANG(b_ngay)) return "";
    var b_kdang = "##/##/####";
    if (b_ngay.length != b_kdang.length) return "Sai kiểu ngày. Vui lòng nhập ngày theo định dạng dd/MM/yyyy";
    for (var i = 0; i < b_kdang.length; i++) {
        var b_c = b_ngay.substr(i, 1);
        if (b_kdang.substr(i, 1) != "#") {
            if (b_c != b_kdang.substr(i, 1)) return "Sai kiểu ngày. Vui lòng nhập ngày theo định dạng dd/MM/yyyy";
        }
        else if ("0123456789".indexOf(b_c) == -1) return "Sai kiểu ngày. Vui lòng nhập ngày theo định dạng dd/MM/yyyy";
    }
    var b_d = parseInt(b_ngay.substr(0, 2), 10), b_m = parseInt(b_ngay.substr(3, 2), 10), b_y = parseInt(b_ngay.substr(6, 4), 10);
    if (b_m < 1 || b_m > 12) return "Tháng từ 1-12";
    if (b_y < 1900 || b_y > 3000) return "Năm từ 1900-3000";
    if (b_kieu == "C" && (b_d < 1 || b_d > Fi_NGAY_THANG(b_m, b_y))) return "Nhập ngày không hợp lệ";
    return "";
}
function ROUNDN(b_so, b_tp) {
    return Math.round(b_so * Math.pow(10, b_tp)) / Math.pow(10, b_tp);
}
//Tim chuoi trong chuoi dang dung
function Fb_MA_MA(b_ngoai, b_trong) {
    if (C_NVL(b_ngoai) == "" || C_NVL(b_trong) == "") return false;
    b_ngoai = b_ngoai.toUpperCase(); b_trong = b_trong.toUpperCase();
    var a_ngoai = b_ngoai.split(',');
    for (var i = 0; i < a_ngoai.length; i++)
        if (a_ngoai[i] == b_trong) return true;
    return false;
}
//Tim chuoi trong chuoi dang dung dau
function Fb_MA_MA_D(b_ngoai, b_trong) {
    if (C_NVL(b_ngoai) == "" || C_NVL(b_trong) == "") return false;
    b_ngoai = b_ngoai.toUpperCase(); b_trong = b_trong.toUpperCase();
    var a_ngoai = b_ngoai.split(',');
    for (var i = 0; i < a_ngoai.length; i++)
        if (a_ngoai[i].indexOf(b_trong) == 0) return true;
    return false;
}
//Tim chuoi trong chuoi dang dung - dung rieng cho Cthuvien:kieu truong hop kieu co nhieu ky tu, e.g 1,2.1,2.2: cho phep go 2,2.
function Fb_MA_MA_D_kieu(b_ngoai, b_trong) {
    if (C_NVL(b_ngoai) == "" || C_NVL(b_trong) == "") return false;
    b_ngoai = b_ngoai.toUpperCase(); b_trong = b_trong.toUpperCase();
    var a_ngoai = b_ngoai.split(',');
    for (var i = 0; i < a_ngoai.length; i++) {
        if (a_ngoai[i] == b_trong) return 1;
        if (a_ngoai[i].indexOf(b_trong) == 0) return 2;
    }
    return 0;
}
//Tim chuoi trong chuoi dang gan dung
function Fb_MA_MA_G(b_ngoai, b_trong) {
    if (C_NVL(b_ngoai) == "" || C_NVL(b_trong) == "") return false;
    b_ngoai = b_ngoai.toUpperCase(); b_trong = b_trong.toUpperCase();
    var a_ngoai = b_ngoai.split(',');
    for (var i = 0; i < a_ngoai.length; i++)
        if (b_trong.indexOf(a_ngoai[i]) >= 0) return true;
    return false;
}

// Convert chuoi thanh bang ten va gia tri [a_ten,a_gtri] cua chuoi dang bang
function Fdt_ch_mang(b_ch) {
    try {
        if (C_NVL(b_ch) == "") return null;
        var a_kq = (b_ch.indexOf('#') < 0) ? b_ch.split(';') : b_ch.split('#');
        var b_cach = (a_kq[0].indexOf('|') < 0) ? ',' : '|';
        var a_ten = a_kq[0].split(b_cach), a_gtri = a_kq[1].split('|');
        return [a_ten, a_gtri];
    }
    catch (err) { return null; }
}
//Convert mang thanh chuoi
function Fs_CONG(a_chu) {
    var b_kq = "";
    for (var i = 0; i < a_chu.length; i++) {
        if (b_kq == "") b_kq = a_chu[i];
        else b_kq += "," + a_chu[i];
    }
    return b_kq;
}
//Them vao chuoi
function kytu_Fs_them(b_cu, b_them) {
    if (b_cu == "" || b_cu == null) b_cu = b_them;
    else b_cu += "," + b_them;
    return b_cu;
}
//Hoi so seri tiep theo
function kytu_Fs_HOI_SERI(b_in) {
    b_in = C_NVL(b_in);
    if (b_in == "") return "1";
    var b_seri = "", b_so = "", b_duoi = "", b_s = "";
    for (var i = 0; i < b_in.length; i++) {
        b_s = b_in.substr(i, 1);
        if ("0123456789".indexOf(b_s) > -1) break;
        b_seri += b_s;
    }
    for (var i = b_seri.length; i < b_in.length; i++) {
        b_s = b_in.substr(i, 1);
        if ("0123456789".indexOf(b_s) < 0) break;
        b_so += b_s;
    }
    b_duoi = b_in.substr(b_seri.length + b_so.length);
    if (b_so == "") b_so = "1";
    else {
        var b_n = CSO_SO(b_so, 2) + 1, b_dai = b_so.length;
        b_so = C_NVL(b_n.toString());
        while (b_so.length < b_dai) b_so = "0" + b_so;
    }
    return b_seri + b_so + b_duoi;
}
function XepXuoiN(a, b) {
    return a - b;
}

// Kiem tra gia tri co trong mang
function Fb_gtri_mang(b_tim, a_tim) {
    try {
        for (var i = 0; i < a_tim.length; i++) if (b_tim == a_tim[i]) return true;
        return false;
    }
    catch (err) { return false; }
}


// Thêm vào mảng a_mang dạng [[ten],[gtri]]
function P_them_mang(a_mang, a_ten, a_gtri) {
    for (var i = 0; i < a_ten.length; i++) { a_mang[0][a_mang[0].length] = a_ten[i]; a_mang[1][a_mang[1].length] = a_gtri[i]; }
}
function mang_Fb_hoiLoai(b_obj) {
    return (b_obj.constructor.toString().indexOf("Array") != -1)
}
function F_DAO(b_gtri, b_lke) {
    if (b_lke == null || b_lke == "") return b_gtri;
    var a_gtri = b_lke.split(","), b_tt = -1, i;
    for (i = 0; i < a_gtri.length; i++) {
        if (b_gtri == a_gtri[i]) { b_tt = i + 1; break; }
    }
    if (b_tt < 0 || b_tt >= a_gtri.length) b_tt = 0;
    return a_gtri[b_tt];
}
function P_DAO(b_ctr, b_lke) {
    try {
        b_ctr.innerHTML = F_DAO(b_ctr.innerHTML, b_lke);
        if (b_ctr.getAttribute("AutoPostBack") == "C" && window.P_KET_QUA != null) window.P_KET_QUA(b_ctr.getAttribute("ten_goc"), [""]);
    }
    catch (err) { }
}

function Fb_LOI_KTRA(b_loi) {
    form_chay = 0;
    if (C_NVL(b_loi) == "") return false;
    return (b_loi.indexOf("loi:") >= 0 && b_loi.lastIndexOf(":loi") >= 0);
}
function P_LOI_KQ(b_loi) {
    if (Fb_LOI_KTRA(b_loi)) form_P_LOI(b_loi);
}
function P_LOI_TGIAN(b_loi) { alert("Lỗi đường truyền"); }
function P_LOI_CSDL(b_loi) { alert(b_loi._message); }


//Tách tên Form từ chuỗi có đường dẫn
function form_Fs_TEN(b_ften) {
    var b_i = b_ften.lastIndexOf("/") + 1;
    var b_ten = (b_i > 0) ? b_ften.substr(b_i) : b_ften;
    b_i = b_ten.indexOf(".");
    if (b_i > 0) b_ten = b_ten.substr(0, b_i);
    return b_ten;
}
// Tra Form goc
function form_F_GOC() {
    var b_g = window, b_f = window.opener;
    try {
        while (b_f != null && b_f != undefined && b_f.name != null) { b_g = b_f; b_f = b_g.opener; }
        b_f = null;
    }
    catch (err) { }
    return b_g;
}




//Hiện lỗi
function form_P_LOI(b_kq) {
    try {
        form_chay = 0;
        var b_loi = (typeof (b_kq) != "string") ? b_kq.message : b_kq;
        b_loi = C_NVL(b_loi);
        if (b_loi == "") return;
        var b_i = b_loi.indexOf("loi:");
        if (b_i >= 0) b_loi = b_loi.substr(b_i + 4);
        b_i = b_loi.lastIndexOf(":loi");
        if (b_i > 0) b_loi = b_loi.substr(0, b_i);
        if (b_loi != "") alert(b_loi);
    }
    catch (err) { }
}
function form_P_KTHUOC(b_rong, b_cao) {
    try {
        if (b_rong == 0) b_rong = screen.availWidth;
        if (b_cao == 0) b_cao = screen.availHeight;
        var b_x = ROUNDN((screen.availWidth - b_rong) / 2, 0), b_y = ROUNDN((screen.availHeight - b_cao) / 2, 0);
        moveTo(b_x, b_y); resizeTo(b_rong, b_cao);
    }
    catch (err) { }
}
//Dat ghi chu tu form
function form_P_DatGchu(b_gchuId, b_kq) {
    try {
        if (C_NVL(b_gchuId) == "" || C_NVL(b_kq) == "") return;
        var b_gchu = $get(b_gchuId);
        if (b_gchu != null && b_gchu != undefined) b_gchu.innerHTML = b_kq;
    }
    catch (err) { }
}
// Tra mang gia tri theo ten
function form_P_TRA_GTRI(b_ten) {
    try {
        var a_ten = b_ten.split(','), a_kq = [];
        for (var i = 0; i < a_ten.length; i++) {
            if (a_ten[i].indexOf(':') < 0) a_kq[i] = form_Fs_TEN_GTRI("", a_ten[i]);
            else {
                var a_grid = a_ten[i].split(':');
                var b_gridId = form_Fs_Grid_ID('', a_grid[0]);
                a_kq[i] = Grid_Fobj_LayGtri_Act(b_gridId, a_grid[1]);
            }
        }
        return a_kq;
    }
    catch (err) { return null; }
}
// Tra gia tri chon cho form goi
function form_P_TRA_CHON(b_ten) {
    try {
        var a_kq = form_P_TRA_GTRI(b_ten);
        form_P_DONG(window.name, a_kq);
        return false;
    }
    catch (err) { form_P_LOI(err); }
}
// Tra ID vung theo 1 ten
function form_Fs_VUNG_ID(b_ten) {
    try {
        var a_ten = b_ten.split(','), b_vungId = "", b_id = "", b_i = 0, b_log = true;
        for (var i = 0; i < a_ten.length; i++) {
            b_ten = a_ten[i].toUpperCase();
            var a_ctr = document.getElementsByTagName("table");
            for (var i = 0; i < a_ctr.length; i++) {
                b_id = a_ctr[i].id.toUpperCase();
                b_i = b_id.indexOf(b_ten);
                if (b_i >= 0) {
                    if (b_id.substr(b_i) == b_ten) { b_vungId = kytu_Fs_them(b_vungId, a_ctr[i].id); b_log = false; break; }
                }
            }
            if (b_log) {
                a_ctr = document.getElementsByTagName("div");
                for (var i = 0; i < a_ctr.length; i++) {
                    b_id = a_ctr[i].id.toUpperCase();
                    b_i = b_id.indexOf(b_ten);
                    if (b_i >= 0) {
                        if (b_id.substr(b_i) == b_ten) { b_vungId = kytu_Fs_them(b_vungId, a_ctr[i].id); b_log = false; break; }
                    }
                }
            }
        }
        return b_vungId;
    }
    catch (err) { return ""; }
}
//Trả vùng theo ID
function form_Fctr_VUNG(b_vungId) {
    var b_vung = (b_vungId == "") ? null : $get(b_vungId);
    if (b_vung == null || b_vung == undefined) b_vung = document;
    return b_vung;
}
//Trả vùng theo ten
function form_Fctr_TENVUNG(b_ten) {
    var b_vungId = form_Fs_VUNG_ID(b_ten);
    return form_Fctr_VUNG(b_vungId);
}

// Tra doi tuong theo 1 ten cua vung qua ten vung
function form_Fctr_VTEN_DTUONG(b_vung, b_ten) {
    var b_vungId = form_Fs_VUNG_ID(b_vung);
    return form_Fctr_TEN_DTUONG(b_vungId, b_ten);
}
// Tra ID doi tuong theo 1 ten cua vung qua ten vung
function form_Fs_VTEN_ID(b_vung, b_ten) {
    var b_vungId = form_Fs_VUNG_ID(b_vung);
    return form_Fctr_TEN_DTUONG(b_vungId, b_ten).id;
}
// Tra ID doi tuong theo 1 ten cua vung qua ID vung
function form_Fs_TEN_ID(b_vungId, b_ten) {
    return form_Fctr_TEN_DTUONG(b_vungId, b_ten).id;
}
// Tra dia chi goc
function form_Fs_ID_GOC() {
    try {
        var a_ctr = document.getElementsByTagName("input"), b_ten = "";
        for (var i = 0; i < a_ctr.length; i++) {
            b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
            if (b_ten == "KTHUOC") {
                var b_dai = a_ctr[i].id.length - 6;
                return a_ctr[i].id.substr(0, b_dai);
            }
        }
        return "";
    }
    catch (err) { return ""; }
}
// Tra doi tuong theo 1 ten cua vung qua ID vung
function form_Fctr_TEN_DTUONG(b_vungId, b_ten) {
    try {
        b_ten = b_ten.toUpperCase();
        var a_vungId = b_vungId.split(','), b_gocId = "", b_id = "", b_ten_goc = "";
        if (b_vungId == "") { b_gocId = form_Fs_ID_GOC(); b_id = b_gocId.toUpperCase() + b_ten; }
        for (var j = 0; j < a_vungId.length; j++) {
            var b_vung = form_Fctr_VUNG(a_vungId[j]);
            var a_ctr = b_vung.getElementsByTagName("input");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i];
                }
            }
            a_ctr = b_vung.getElementsByTagName("span");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i];
                }
            }
            a_ctr = b_vung.getElementsByTagName("select");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i];
                }
            }
            a_ctr = b_vung.getElementsByTagName("textarea");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i];
                }
            }
            a_ctr = b_vung.getElementsByTagName("button");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i];
                }
            }
            a_ctr = b_vung.getElementsByTagName("img");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i];
                }
            }
        }
        return null;
    }
    catch (err) { return null; }
}
// Tra gia tri 1 ten cua vung qua ID
function form_Fs_TEN_GTRI(b_vungId, b_ten) {
    try {
        b_ten = b_ten.toUpperCase();
        var a_vungId = b_vungId.split(','), b_gocId = "", b_id = "", b_ten_goc = "";
        if (b_vungId == "") { b_gocId = form_Fs_ID_GOC(); b_id = b_gocId.toUpperCase() + b_ten; }
        for (var j = 0; j < a_vungId.length; j++) {
            var b_vung = form_Fctr_VUNG(a_vungId[j]);
            var a_ctr = b_vung.getElementsByTagName("input");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i].value;
                }
            }
            a_ctr = b_vung.getElementsByTagName("span");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i].innerHTML;
                }
            }
            a_ctr = b_vung.getElementsByTagName("select");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i].value;
                }
            }
            a_ctr = b_vung.getElementsByTagName("textarea");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten_goc = C_NVL(a_ctr[i].getAttribute("ten_goc")).toUpperCase();
                if (b_ten == b_ten_goc) {
                    if (b_gocId == "" || b_id == a_ctr[i].id.toUpperCase()) return a_ctr[i].value;
                }
            }
        }
        return "";
    }
    catch (err) { return ""; }
}
// Tra gia tri 1 ten cua vung qua ten
function form_Fs_VTEN_GTRI(b_vung, b_ten) {
    var b_vungId = form_Fs_VUNG_ID(b_vung);
    return form_Fs_TEN_GTRI(b_vungId, b_ten);
}
// Tra gia tri 1 vung
function form_Fs_TEXT_KTRA(b_vungId) {
    try {
        var b_kq = "";
        var b_gtri = "", b_ten = "", b_loi = [""], b_kt = -1, a_ten = [], a_gtri = [];
        var a_vungId = b_vungId.split(',');
        for (var j = 0; j < a_vungId.length; j++) {
            var b_vung = form_Fctr_VUNG(a_vungId[j]);
            var a_ctr = b_vung.getElementsByTagName("input");
            for (var i = 0; i < a_ctr.length; i++) {
                if (C_NVL(a_ctr[i].getAttribute("nhap")).toUpperCase() == "C") {
                    b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc"));
                    if (b_ten == b_ten.toUpperCase()) {
                        b_gtri = C_NVL(a_ctr[i].value); b_ten = C_NVL(a_ctr[i].getAttribute("ten"));
                        if (a_ctr[i].getAttribute("kieu_date") != null) {
                            if (Fb_NGAY_TRANG(b_gtri)) return "Phải nhập " + b_ten;
                        }
                        else if (a_ctr[i].getAttribute("so_tp") != null) {
                            if (CSO_SO(b_gtri, 5) == 0) return "Phải nhập " + b_ten;
                        }
                        else if (b_gtri == "") return "Phải nhập " + b_ten;
                    }

                    if (a_ctr[i].getAttribute("kieu_date") != null && a_ctr[i].getAttribute("kieu_date").toUpperCase() != "K") {
                        b_gtri = C_NVL(a_ctr[i].value); b_ten = C_NVL(a_ctr[i].getAttribute("ten"));
                        b_loi = Fs_NGAY_LOI(b_gtri, a_ctr[i].getAttribute("kieu_date"));
                        if (b_loi != "") return b_loi + " tại trường " + b_ten;
                    }

                    b_kq = KiemTraKyTuDacBiet(a_ctr[i]);
                    if (b_kq != "") return b_kq;
                }
            }


            a_ctr = b_vung.getElementsByTagName("span");
            for (var i = 0; i < a_ctr.length; i++) {
                if (C_NVL(a_ctr[i].getAttribute("nhap")).toUpperCase() == "C") {
                    b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc"));
                    if (b_ten == b_ten.toUpperCase()) {
                        if (C_NVL(a_ctr[i].innerHTML) == "") return "Phải nhập " + C_NVL(a_ctr[i].getAttribute("ten"));
                    }

                    b_kq = KiemTraKyTuDacBiet(a_ctr[i]);
                    if (b_kq != "") return b_kq;
                }
            }

            a_ctr = b_vung.getElementsByTagName("textarea");
            for (var i = 0; i < a_ctr.length; i++) {
                if (C_NVL(a_ctr[i].getAttribute("nhap")).toUpperCase() == "C") {
                    b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc"));
                    if (b_ten == b_ten.toUpperCase()) {
                        if (C_NVL(a_ctr[i].value) == "") return "Phải nhập " + C_NVL(a_ctr[i].getAttribute("ten"));
                    }

                    b_kq = KiemTraKyTuDacBiet(a_ctr[i]);
                    if (b_kq != "") return b_kq;
                }
            }
        }
        return b_kq;
    }
    catch (err) { return err }
}

function KiemTraKyTuDacBiet(b_ctr) {
    var b_kq = "";

    try {
        var choPhepKyTuDacBiet = C_NVL(b_ctr.getAttribute("ky_tu_dac_biet")).toUpperCase();
        var b_gtri = C_NVL(b_ctr.value);
        var b_ten = C_NVL(b_ctr.getAttribute("ten"));
        if (choPhepKyTuDacBiet == "FALSE") {
            var n = b_gtri.search(new RegExp("[^a-zA-Z0-9]", "g"));
            if (n != -1)
                b_kq = "Vui lòng chỉ nhập các ký tự chữ cái và chữ số tại trường " + b_ten;
        }
        else if (choPhepKyTuDacBiet == "SO_CTGS") {
            var n = b_gtri.search(new RegExp("[^a-zA-Z0-9/\\.:_-]", "g"));
            if (n != -1)
                b_kq = "Vui lòng chỉ nhập các ký tự chữ cái, chữ số và các ký tự đặc biệt cho phép (-_/\.:) tại trường " + b_ten;
        }
        else if (choPhepKyTuDacBiet.indexOf("EXCEPT_") == 0) {
            var pattern = b_ctr.getAttribute("ky_tu_dac_biet").substring(7);
            var n = b_gtri.search(new RegExp(pattern, "g"));
            if (n != -1)
                b_kq = "Lỗi nhập ký tự đặc biệt tại trường " + b_ten + ": " + C_NVL(b_ctr.getAttribute("ky_tu_dac_biet_ghi_chu"));
        }
        else if (choPhepKyTuDacBiet.indexOf("REGEX_") == 0) {
            var pattern = b_ctr.getAttribute("ky_tu_dac_biet").substring(6);
            var n = b_gtri.search(new RegExp(pattern, "g"));
            if (n != -1)
                b_kq = "Lỗi nhập ký tự đặc biệt tại trường " + b_ten + ": " + C_NVL(b_ctr.getAttribute("ky_tu_dac_biet_ghi_chu"));
        }
    }
    catch (err) { }

    return b_kq;
}

function form_Faa_TEXT_ROW(b_vungId) {
    try {
        var b_dateVar = new Date();
        var b_datenam = b_dateVar.getFullYear();
        //if (b_datenam < 2000 || b_datenam > 2000 + 10 + 2) return;
        var b_gtri = "", b_kt = -1, a_ten = [], a_gtri = [], b_so_tp = 0;
        var a_vungId = b_vungId.split(',');
        for (var j = 0; j < a_vungId.length; j++) {
            var b_vung = form_Fctr_VUNG(a_vungId[j]);
            var a_ctr = b_vung.getElementsByTagName("input");
            for (var i = 0; i < a_ctr.length; i++) {
                if (C_NVL(a_ctr[i].getAttribute("nhap")).toUpperCase() == "C") {
                    b_kt++; a_ten[b_kt] = a_ctr[i].getAttribute("ten_goc"); b_gtri = C_NVL(a_ctr[i].value);
                    if (a_ctr[i].getAttribute("kieu_date") != null) {
                        if (a_ctr[i].getAttribute("kieu_luu") == "D") a_gtri[b_kt] = CNG_NG(b_gtri);
                        else if (a_ctr[i].getAttribute("kieu_luu") == "I") a_gtri[b_kt] = CNG_SO(b_gtri);
                        else a_gtri[b_kt] = b_gtri;
                    }
                    else if (a_ctr[i].getAttribute("so_tp") != null) {
                        b_so_tp = CSO_SO(a_ctr[i].getAttribute("so_tp"), 0);
                        a_gtri[b_kt] = CSO_SO(b_gtri, b_so_tp);
                    }
                    else if (C_NVL(a_ctr[i].getAttribute("kieu_unicode")) == "C" && b_gtri != "") a_gtri[b_kt] = "N'" + b_gtri;
                    else a_gtri[b_kt] = b_gtri;
                }
            }
            a_ctr = b_vung.getElementsByTagName("textarea");
            for (var i = 0; i < a_ctr.length; i++) {
                if (C_NVL(a_ctr[i].getAttribute("nhap")).toUpperCase() == "C") {
                    b_kt++; a_ten[b_kt] = a_ctr[i].getAttribute("ten_goc"); b_gtri = C_NVL(a_ctr[i].value);
                    if (C_NVL(a_ctr[i].getAttribute("kieu_unicode")) == "C" && b_gtri != "") a_gtri[b_kt] = "N'" + b_gtri;
                    else a_gtri[b_kt] = b_gtri;
                }
            }
            a_ctr = b_vung.getElementsByTagName("span");
            for (var i = 0; i < a_ctr.length; i++) {
                if (C_NVL(a_ctr[i].getAttribute("nhap")).toUpperCase() == "C") {
                    b_kt++; a_ten[b_kt] = a_ctr[i].getAttribute("ten_goc"); a_gtri[b_kt] = C_NVL(a_ctr[i].innerHTML);
                }
            }
            a_ctr = b_vung.getElementsByTagName("select");
            for (var i = 0; i < a_ctr.length; i++) {
                if (C_NVL(a_ctr[i].getAttribute("nhap")).toUpperCase() == "C") {
                    b_kt++; a_ten[b_kt] = a_ctr[i].getAttribute("ten_goc"); b_gtri = C_NVL(a_ctr[i].value);
                    if (C_NVL(a_ctr[i].getAttribute("kieu_unicode")) == "C") a_gtri[b_kt] = "N'" + b_gtri;
                    else a_gtri[b_kt] = b_gtri;
                }
            }
        }
        return [a_ten, a_gtri];
    }
    catch (err) { form_P_LOI(err); }
}
function form_P_MANG_TEXT(b_vungId, a_ten, a_gtri) {
    try {
        var b_dateVar = new Date();
        var b_datenam = b_dateVar.getFullYear();
        //if (b_datenam < 2000 || b_datenam > 2000 + 10 + 2) return;
        var b_vtri = 0, b_ten = "", a_vungId = b_vungId.split(','), b_so_tp = 0;
        for (var j = 0; j < a_vungId.length; j++) {
            var b_vung = form_Fctr_VUNG(a_vungId[j]);
            var a_ctr = b_vung.getElementsByTagName("input");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc"));
                if (b_ten != "") {
                    b_vtri = Fi_vtri_mang(a_ten, b_ten);
                    if (b_vtri >= 0) {
                        if (a_ctr[i].getAttribute("so_tp") != null) {
                            b_so_tp = CSO_SO(a_ctr[i].getAttribute("so_tp"), 0); a_ctr[i].value = SO_CSO(a_gtri[b_vtri], b_so_tp);
                        }
                        else if (a_ctr[i].getAttribute("kieu_date") != null && C_NVL(a_ctr[i].getAttribute("kieu_luu")) == "I") a_ctr[i].value = CSO_CNG(a_gtri[b_vtri]);
                        else a_ctr[i].value = C_NVL(a_gtri[b_vtri]);
                    }
                }
            }
            a_ctr = b_vung.getElementsByTagName("textarea");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc"));
                if (b_ten != "") {
                    b_vtri = Fi_vtri_mang(a_ten, b_ten);
                    if (b_vtri >= 0) a_ctr[i].value = C_NVL(a_gtri[b_vtri]);
                }
            }
            a_ctr = b_vung.getElementsByTagName("span");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc"));
                if (b_ten != "") {
                    b_vtri = Fi_vtri_mang(a_ten, b_ten);
                    if (b_vtri >= 0) a_ctr[i].innerHTML = C_NVL(a_gtri[b_vtri]);
                }
            }
            a_ctr = b_vung.getElementsByTagName("select");
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc"));
                if (b_ten != "" && C_NVL(a_ctr[i].getAttribute("nhap")) == "C") {
                    b_vtri = Fi_vtri_mang(a_ten, b_ten);
                    if (b_vtri >= 0) a_ctr[i].value = C_NVL(a_gtri[b_vtri]);
                }
            }
        }
    }
    catch (err) { form_P_LOI(err); }
}
function form_P_CH_TEXT(b_vungId, b_ch) {
    try {
        var a_json = Lib.Common.stringToJson(b_ch);
        var b_dt = Fa_Json_Mang(a_json[0]);
        if (b_dt != null) form_P_MANG_TEXT(b_vungId, b_dt[0], b_dt[1]);
    }
    catch (err) { form_P_LOI(err); }
}
function form_P_Grid_TEXT(b_vungId, gridId) {
    try {
        var a_dr = Grid_Fdr_CotGtri_Act(gridId);
        form_P_MANG_TEXT(b_vungId, a_dr[0], a_dr[1]);
    }
    catch (err) { form_P_LOI(err); }
}
// An Control
function form_P_AN_CTR(b_ctrId) {
    var a_ctrId = b_ctrId.split(',');
    for (var i = 0; i < a_ctrId.length; i++) $get(a_ctrId[i]).style.display = "none";
}
// Dat cho phep sua hoac khong sua
function form_P_SUA_CTR(b_ctrId, b_dk) {
    var a_ctrId = b_ctrId.split(',');
    for (var i = 0; i < a_ctrId.length; i++) {
        var b_ctr = $get(a_ctrId[i]);
        b_ctr.enabled = b_dk; b_ctr.disabled = !b_dk;
    }
}
// Dat mau cac link trong vung
function form_P_MAU_LINK(b_vungId, b_mau, b_chuan, b_dt) {
    try {
        var b_vung = form_Fctr_VUNG(b_vungId);
        var a_ctr = b_vung.getElementsByTagName("span"), b_tt = "", b_ten = "";
        if (b_dt != null) {
            for (var i = 0; i < a_ctr.length; i++) {
                b_ten = C_NVL(a_ctr[i].getAttribute("ten_goc"));
                if (b_ten != "") {
                    b_tt = Fobj_gtri_mang(b_dt[0], b_dt[1], b_ten);
                    if (b_tt == null) b_tt = b_chuan;
                    a_ctr[i].className = b_mau + b_tt;
                }
            }
        }
        else {
            b_mau += b_chuan;
            for (var i = 0; i < a_ctr.length; i++) {
                if (C_NVL(a_ctr[i].getAttribute("ten_goc")) != "") a_ctr[i].className = b_mau;
            }
        }
    }
    catch (err) { }
}
// Day dong bo
function form_P_DBO(b_form) {
    try {
        if (b_form != "") {
            var a_form = b_form.split(',');
            for (var i = 0; i < a_form.length; i++) form_P_DAY(window.name, a_form[i], "DBO", [""]);
        }
    }
    catch (err) { }
}
// Kiem tra SE
function form_P_KTRA_SE() {
    try { skhac.Fs_KTRA_SE(P_LOI_KQ, P_LOI_CSDL, P_LOI_TGIAN); }
    catch (err) { }
}
function kytu_locUnicode(a_gtri) {
    var b_s = "";
    for (var i = 0; i < a_gtri.length; i++) {
        if (a_gtri[i] != null) {
            b_s = a_gtri[i].toString();
            if (b_s.substr(0, 2) == "N'") a_gtri[i] = b_s.substr(2);
        }
    }
    return a_gtri;
}
function P_TAB(b_ctr) {
    try {
        var b_dateVar = new Date();
        var b_datenam = b_dateVar.getFullYear();
        //if (b_datenam < 2000 || b_datenam > 2000 + 10 + 2) return;
        var b_PaId = C_NVL(b_ctr.getAttribute("PaId"));
        if (b_PaId != "") {
            var b_Pa = $get(b_ctr.getAttribute("PaId"));
            if (b_Pa.style.display == "block") return;
        }
        var b_ceId = C_NVL(b_ctr.getAttribute("CeId"));
        var b_css = (b_ceId == "") ? b_ctr.className : $get(b_ceId).className;
        var b_i = b_css.lastIndexOf("_");
        b_css = b_css.substr(0, b_i);
        var b_vung = form_Fctr_VUNG(b_ctr.getAttribute("TaId"));
        var a_ctr = b_vung.getElementsByTagName("span");
        for (var i = 0; i < a_ctr.length; i++) {
            if (a_ctr[i].id.indexOf("login") < 0) {
                b_ceId = C_NVL(a_ctr[i].getAttribute("CeId"));
                if (b_ceId == "") a_ctr[i].className = b_css + "_de"; else $get(b_ceId).className = b_css + "_de";
                if (b_PaId != "") $get(a_ctr[i].getAttribute("PaId")).style.display = "none";
            }
        }
        if (b_PaId != "") b_Pa.style.display = "block";
        b_ceId = C_NVL(b_ctr.getAttribute("CeId"));
        if (b_ceId == "") b_ctr.className = b_css + "_ac"; else $get(b_ceId).className = b_css + "_ac";
        var b_ham = C_NVL(b_ctr.getAttribute("ham"));
        if (b_ham != "") eval(b_ham);
    }
    catch (err) { form_P_LOI(err); }
}
function P_BAR(b_ctr) {
    try {
        var b_css = b_ctr.className;
        var b_i = b_css.lastIndexOf("_");
        b_css = b_css.substr(0, b_i);
        if (b_ctr.className == b_css + "_ac") return;
        var b_vung = form_Fctr_VUNG(b_ctr.getAttribute("TaId"));
        var a_ctr = b_vung.getElementsByTagName("span");
        for (var i = 0; i < a_ctr.length; i++) {
            if (a_ctr[i].className == b_css + "_ac") { a_ctr[i].className = b_css + "_de"; break; }
        }
        b_ctr.className = b_css + "_ac";
        var b_ham = C_NVL(b_ctr.getAttribute("ham"));
        if (b_ham != null) eval(b_ham);
    }
    catch (err) { }
}
function P_ROI(b_tso) {
    try {
        var a_tso = b_tso.split('#');
        var b_f = a_tso[1], b_gui = a_tso[2], b_ham = a_tso[3];
        if (b_ham != "") { eval(b_ham); return; }
        if (b_f == "") return;
        var a_gui = null, a_gtri = null;
        if (b_gui != "") a_gtri = form_P_TRA_GTRI(b_gui);
        if (a_tso[0] == "C") {
            if (a_gtri == null) a_gtri = ["DONG", window.name];
            else { a_gtri[a_gtri.length] = "DONG"; a_gtri[a_gtri.length] = window.name; }
        }
        if (a_gtri != null) {
            var b_dtuong = (a_tso[5] == "") ? "THAMSO" : a_tso[5];
            a_gui = [b_dtuong, a_gtri];
        }
        form_P_MO(b_f, window.name + "," + a_tso[4], a_gui);
    }
    catch (err) { }
}
function drop_P_THEM(b_dropId, source) {
    try {
        var b_ctr = $("#" + b_dropId);
        var aJSon = Lib.Common.stringToJson(source);
        b_ctr.children().remove();
        $.each(aJSon, function (val, text) {
            $.each(text, function (a, b) {
                b_ctr.append($('<option></option>').val(b).html(b));
            });
        });
    }
    catch (err) { }
}

function Fas_ChMang(e, t) {
    try {
        if (e == null) return null;
        var n = [], r, i = t.length;
        while (e != null) {
            r = e.indexOf(t);
            if (r < 0) {
                n[n.length] = e;
                e = null
            }
            else {
                n[n.length] = e.substr(0, r);
                e = e.substr(r + i)
            }
        }
        return n
    }
    catch (s) {
        return null
    }
}

//Xoa 1 vung theo b_dk - (XGL)
function form_P_MOI(b_vungId, b_dk) {
    try {
        var b_dateVar = new Date();
        var b_datenam = b_dateVar.getFullYear();
        //if (b_datenam < 2000 || b_datenam > 2000 + 10 + 2) return;
        var a_vungId = b_vungId.split(','), b_kt_xoa = "";
        for (var j = 0; j < a_vungId.length; j++) {
            var b_vung = form_Fctr_VUNG(a_vungId[j]);
            var a_ctr = b_vung.getElementsByTagName("input");
            for (var i = 0; i < a_ctr.length; i++) {
                b_kt_xoa = C_NVL(a_ctr[i].getAttribute("kt_xoa"));
                if (b_kt_xoa != "" && b_dk.indexOf(b_kt_xoa) >= 0) a_ctr[i].value = "";
            }
            var a_ctr = b_vung.getElementsByTagName("textarea");
            for (var i = 0; i < a_ctr.length; i++) {
                b_kt_xoa = C_NVL(a_ctr[i].getAttribute("kt_xoa"));
                if (b_kt_xoa != "" && b_dk.indexOf(b_kt_xoa) >= 0) a_ctr[i].value = "";
            }
            a_ctr = b_vung.getElementsByTagName("span");
            for (var i = 0; i < a_ctr.length; i++) {
                b_kt_xoa = C_NVL(a_ctr[i].getAttribute("kt_xoa"));
                if (b_kt_xoa != "" && b_dk.indexOf(b_kt_xoa) >= 0) a_ctr[i].innerHTML = "";
            }
        }
    }
    catch (err) { }
}

//QuangNN - lấy vị trí con trỏ trong control
function doGetCaretPosition(ctrl) {
    var CaretPos = 0;   // IE Support
    if (document.selection) {
        ctrl.focus();
        var Sel = document.selection.createRange();
        Sel.moveStart('character', -ctrl.value.length);
        CaretPos = Sel.text.length;
    }
    // Firefox support
    else if (ctrl.selectionStart || ctrl.selectionStart == '0')
        CaretPos = ctrl.selectionStart;
    return (CaretPos);
}

//QuangNN - đặt vị trí con trỏ trong control
function setCaretPosition(ctrl, pos) {
    if (ctrl.setSelectionRange) {
        ctrl.focus();
        ctrl.setSelectionRange(pos, pos);
    }
    else if (ctrl.createTextRange) {
        var range = ctrl.createTextRange();
        range.collapse(true);
        range.moveEnd('character', pos);
        range.moveStart('character', pos);
        range.select();
    }
}

//QuangNN (26/05/2014)
function startsWith(str, prefix) {
    return str.slice(0, prefix.length) == prefix;
}

//QuangNN (26/05/2014)
function endsWith(str, suffix) {
    return str.slice(-suffix.length) == suffix;
}

//QuangNN (08/06/2014) - chua hoat dong
//Grid - Dat do rong cot
function Grid_P_RongCot(gridId, b_cot, b_rong) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_columns = b_grid.columns;
        var b_icot = Grid_Fi_TtuCot(gridId, b_cot);

        for (var i = 0; i < b_rows.length; i++) {
            $("#" + gridId + " tbody tr:eq(" + i + ") td:eq(" + b_icot + ")").css('width', 300);
        }
    }
    catch (ex) { }
}

//QuangNN (27/05/2014) - OK
function slide_Fs_TENID(b_ten) {
    try {
        var b_id = form_Fs_TEN_ID("", b_ten + "_an");
        var b_i = b_id.lastIndexOf("_");
        return b_id.substr(0, b_i);
    }
    catch (err) { return null; }
}

//QuangNN (27/05/2014) - OK
function slide_Faobj_TUDEN(gridID) {
    try {
        var b_TrangCu = Lib.Common.getCurrentPage(gridID);
        var pageCount = CSO_SO(Lib.Common.getTotalPage(gridID), 0);
        var pageSize = CSO_SO($("#" + gridID).attr("page_size"), 0);
        var b_tu = (b_TrangCu - 1) * pageSize + 1;
        var b_den = b_tu + parseInt(pageSize) - 1;
        //var b_an = $get(slideId + "_an");
        //var b_trang = CSO_SO(b_an.value, 0), b_kthuoc = CSO_SO(b_an.getAttribute("TrangKt"), 0), b_TrangCu = CSO_SO(b_an.getAttribute("TrangCu"), 0);
        //var b_tu = (b_trang - 1) * b_kthuoc + 1;
        //var b_den = b_tu + b_kthuoc - 1;
        return [b_tu, b_den, b_TrangCu];
    }
    catch (err) { return null; }
}

//QuangNN (27/05/2014)
function slide_P_SOTRANG(gridID, b_soDong) {
    try {
        Lib.Common.setTotalPage(gridID, b_soDong);
    }
    catch (err) { form_P_LOI(err); }
}
//QuangNN (27/05/2014)
function slide_P_MOI(gridID, b_trang) {
    try {
        Lib.Common.setCurrentPage(gridID, b_trang);
    }
    catch (err) { form_P_LOI(err); }
}

//QuangNN (27/05/2014)
function slide_P_CHUYEN(slideId, b_dk) {
    try {
        var b_an = $get(slideId + "_an");
        var b_cu = CSO_SO(b_an.value, 0);
        var b_moi = b_cu;
        if (b_dk == "P") {
            var b_soTrang = CSO_SO($get(slideId + "_trang").innerHTML, 0);
            if (b_cu < b_soTrang) b_moi++;
        }
        else if (b_dk == "T" && b_cu > 1) b_moi--;
        if (b_moi != b_cu) {
            Attribute_P_DAT(b_an, "TrangCu", b_cu);
            b_an.value = b_moi;
            if (b_an.onchange) b_an.onchange();
        }
        return false;
    }
    catch (err) { form_P_LOI(err); }
}

// Chuyển mảng Json thành mảng chuôi
function Fa_Json_Mang(b_json) {
    var a_ten = [], a_gtri = [];
    var i = 0;
    jQuery.each(b_json, function (name, value) {
        a_ten[i] = name;
        a_gtri[i] = value;
        i++
    });
    return [a_ten, a_gtri];
}
//Tìm giá trị Json
function Fs_Json_Gtri(json, b_ten) {
    var a_json = Lib.Common.stringToJson(json);
    return a_json[0][b_ten];
}

//QuangNN (14/08/2014)
//Tính số hàng trên lưới phân trang theo số hàng dữ liệu và page_size
function Fi_RowNumber(length, page_size) {
    return Math.max(Math.ceil(length / page_size) * page_size, page_size);
}

//QuangNN (22/05/2014)
//Grid - Dat gia tri grid co phan trang tu chuoi
function Grid_P_DatBangCHPT(gridId, b_ch) {
    Grid_P_DatBangCH(gridId, b_ch);
}

//QuangNN (13/08/2014)
//Grid - Cat hang theo dieu kien tren luoi co phan trang
function Grid_cutRowDKPT(gridId, b_cot, b_gtri) {
    Grid_cutRowDK(gridId, b_cot, b_gtri);
}

//QuangNN (30/07/2014) - Grid_DatActiveRow
//Grid - Cat hang Active tren luoi co phan trang
function Grid_cutRowActPT(gridId) {
    Grid_cutRowAct(gridId);
}

//Đặt lại LKE
function Grid_P_DatLke(gridID, b_tencot, b_gtri) {
    var b_grid = $("#" + gridID).data("kendoGrid");
    var b_columns = b_grid.columns;
    for (var i = 0; i < b_columns.length; i++) {
        if (b_columns[i].field.toUpperCase() == b_tencot.toUpperCase()) {
            b_columns[i].lke = b_gtri;
        }
    }
}






/*---------------MA HOA --------------------------*/

//QuangNN (22/07/2014)
//Grid - Dem hang thoa man dieu kien don dong
function Grid_Fi_DemHangD(gridId, b_cot, b_gtri, b_dk) {
    try {
        var b_count = 0;
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        for (var i = 0; i < b_rows.length; i++) {
            var b_cu = Grid_Fobj_LayGtri(gridId, i, b_cot.toUpperCase());
            if (eval('b_cu != null && b_cu ' + b_dk + 'b_gtri')) b_count++;
        }
        return b_count;
    }
    catch (ex) { return 0; }
}
//QuangNN (22/07/2014)
//Grid - Dem hang thoa man dieu kien mang dong
function Grid_Fi_DemHangND(gridId, a_cot, a_gtri, a_dk) {
    try {
        var b_count = 0;
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_log = true;

        for (var i = 0; i < b_rows.length; i++) {
            b_log = true;
            for (var j = 0; j < a_cot.length; j++) {
                var b_cu = Grid_Fobj_LayGtri(gridId, i, a_cot[j].toUpperCase());
                if (eval("b_cu == null || !(b_cu " + a_dk[j] + " a_gtri[j])")) { b_log = false; break; }
            }

            if (b_log) b_count++;
        }
        return b_count;
    }
    catch (ex) { return 0; }
}
//QuangNN (31/05/2014) - Chua test ki
//Grid - Tim hang lon nhat thoa man dieu kien mang dong
function Grid_Fi_TimHangM(gridId, a_cot, a_gtri, a_dk) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_log = true, b_hang = -1;

        for (var i = 0; i < b_rows.length; i++) {
            b_log = true;

            for (var j = 0; j < a_cot.length; j++) {
                var b_cu = Grid_Fobj_LayGtri(gridId, i, a_cot[j].toUpperCase());

                if (eval("b_cu == null || !(b_cu" + a_dk[j] + "a_gtri[j])")) { b_log = false; break; }
            }

            if (b_log) b_hang = i;
            else if (b_hang >= 0) break;
        }

        return b_hang;
    }
    catch (ex) { return -1; }
}
//QuangNN (30/05/2014)
//Grid - Tim hang thoa man dieu kien mang dong
function Grid_Fi_TimHangND(gridId, a_cot, a_gtri, a_dk) {
    try {
        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();
        var b_log = true;

        for (var i = 0; i < b_rows.length; i++) {
            b_log = true;
            for (var j = 0; j < a_cot.length; j++) {
                var b_cu = Grid_Fobj_LayGtri(gridId, i, a_cot[j].toUpperCase());

                if (eval("b_cu == null || !(b_cu " + a_dk[j] + " a_gtri[j])")) { b_log = false; break; }
            }

            if (b_log) return i;
        }
        return -1;
    }
    catch (ex) { return -1; }
}

//QuangNN (23/05/2014)
//Grid - Tim hang thoa man dieu kien don dong
function Grid_Fi_TimHangD(gridId, b_cot, b_gtri, b_dk) {
    try {
        b_cot = b_cot.toUpperCase();

        var b_grid = $("#" + gridId).data("kendoGrid");
        var b_rows = b_grid.dataSource.data();

        for (var i = 0; i < b_rows.length; i++) {
            var b_cu = Grid_Fobj_LayGtri(gridId, i, b_cot);
            if (eval('b_cu != null && b_cu ' + b_dk + 'b_gtri')) return i;
        }

        return -1;
    }
    catch (ex) { return -1; }
}
//Dat Attribute
function Attribute_P_DAT(b_ctr, b_ten, b_gtri) {
    try {
        var a_ten = mang_Fb_hoiLoai(b_ten) ? b_ten : b_ten.split(',');
        var a_gtri = mang_Fb_hoiLoai(b_gtri) ? b_gtri : [b_gtri];
        if (b_ctr.setAttribute) {
            for (var i = 0; i < a_ten.length; i++) b_ctr.setAttribute(a_ten[i], a_gtri[i]);
        }
        else { for (var i = 0; i < a_ten.length; i++) eval("b_ctr." + a_ten[i] + "=a_gtri[i]"); }
    }
    catch (ex) { }
}
// Tra form theo ten
function form_Fc_TEN(b_ten) {
    try {
        var b_goc = form_F_GOC();
        return eval('b_goc.' + b_ten);
    }
    catch (err) { return null; }
}
// Kiem tra form da mo
function form_Fb_MO(b_ten) {
    var b_goc = form_F_GOC();
    return (eval('b_goc.' + b_ten) != null && eval('b_goc.' + b_ten) != undefined && eval('b_goc.' + b_ten).name != null);
}
// Mo form
var form_choId = 0, form_choTen = "", form_choTso, form_choDem = 0, form_se = 0, form_chay = 0;
function form_P_MO(b_tenf, b_mo, a_tso, b_bbuoc) {
    try {
        var b_dateVar = new Date();
        var b_datenam = b_dateVar.getFullYear();
        //if (b_datenam < 2000 || b_datenam > 2000 + 10 + 2) return;
        var b_goc = form_F_GOC(), b_ten = form_Fs_TEN(b_tenf);
        var b_damo = b_goc.damo, b_s = "";
        if (b_damo == null || b_damo == undefined) b_damo = "";
        if (eval("b_goc." + b_ten) == null || b_bbuoc == "C") {
            if (eval("b_goc." + b_ten) != null) eval("b_goc." + b_ten + "=null;");
            var b_rong = 100, b_cao = 40;
            if (b_bbuoc == "C") { b_rong = screen.availWidth; b_cao = screen.availHeight; }
            var b_x = ROUNDN((screen.availWidth - b_rong) / 2, 0).toString(), b_y = ROUNDN((screen.availHeight - b_cao) / 2, 0).toString();
            var b_opt = "width=" + b_rong.toString() + ",height=" + b_cao.toString() + ",left=" + b_x + ",top=" + b_y;
            //b_opt += ",resizable=yes,location=yes,scrollbars=yes";
            b_opt += ",alwaysRaised=yes";
            eval("b_goc." + b_ten + "=b_goc.open('" + b_tenf + "','','" + b_opt + "');");
            if (!Fb_MA_MA(b_damo, b_ten)) b_goc.damo = kytu_Fs_them(b_damo, b_ten);
        }
        eval("b_goc." + b_ten + ".damo=b_mo;");
        eval("b_goc." + b_ten + ".focus();");
        eval("b_goc").temp = b_mo;
        if (a_tso != null && a_tso != "") {
            var b_f = eval("b_goc." + b_ten);
            if (b_f.P_KET_QUA != null) b_f.P_KET_QUA(a_tso[0], a_tso[1]);
            else {
                if (form_choId != 0) clearTimeout(form_choId);
                form_choTen = b_ten; form_choTso = a_tso; form_choDem = 0;
                form_choId = setInterval('form_P_MO_CHO()', 500);
            }
        }
        return false;
    }
    catch (err) { form_P_LOI(err); }
}
function form_P_MO_CHO() {
    try {
        form_choDem++;
        if (C_NVL(form_choTen) == "" || form_choDem > 40) { clearTimeout(form_choId); return; }
        var b_goc = form_F_GOC();
        var b_f = eval("b_goc." + form_choTen);
        if (b_f == null) return;
        if (b_f.P_KET_QUA != null) {
            clearTimeout(form_choId); formm_choTen = null;
            b_f.P_KET_QUA(form_choTso[0], form_choTso[1]);
        }
    }
    catch (err) { }
}
// Dong form
function form_P_DONG(b_ten, a_tso) {
    try {
        var b_dateVar = new Date();
        var b_datenam = b_dateVar.getFullYear();
        //if (b_datenam < 2000 || b_datenam > 2000 + 10 + 2) return;
        if (b_ten == "login") return;
        var b_goc = form_F_GOC();
        var b_damo = b_goc.damo;
        if (b_damo == null || b_damo == undefined || b_damo == "") return;
        var a_damo = b_damo.split(',');
        if (b_ten != b_goc.name) {
            var b_tra = eval("b_goc." + b_ten + ".damo;");
            if (b_tra == null || b_tra == undefined)
                b_tra = eval("b_goc").temp;
            eval("b_goc." + b_ten + ".close();"); eval("b_goc." + b_ten + "=null;");
            b_damo = "";
            for (var i = 0; i < a_damo.length; i++) {
                if (a_damo[i] != b_ten) b_damo = kytu_Fs_them(b_damo, a_damo[i]);
            }
            b_goc.damo = b_damo;
            if (a_tso != null && b_tra != null && b_tra != "") {
                var a_s = b_tra.split(',');
                if (Fb_MA_MA(b_damo, a_s[0])) {
                    if (eval("b_goc." + a_s[0] + ".P_KET_QUA") != null) {
                        eval("b_goc." + a_s[0] + ".focus();");
                        eval("b_goc." + a_s[0] + ".P_KET_QUA(a_s[1], a_tso);");
                    }
                }
            }
        }
        else {
            for (var i = 0; i < a_damo.length; i++) {
                eval("b_goc." + a_damo[i] + ".close();"); eval("b_goc." + a_damo[i] + "=null;");
            }
        }
    }
    catch (err) { }
}

// Dong form
function form_P_DONG1(b_ten, a_tso) {
    debugger;
    try {
        var b_dateVar = new Date();
        var b_datenam = b_dateVar.getFullYear();
        debugger;
        //if (b_datenam < 2000 || b_datenam > 2000 + 10 + 2) return;
        if (b_ten == "login") return;
        var b_goc = form_F_GOC();
        var b_damo = b_goc.damo;
        if (b_damo == null || b_damo == undefined || b_damo == "") return;
        var a_damo = b_damo.split(',');
        if (b_ten != b_goc.name) {
            var b_tra = eval("b_goc." + b_ten + ".damo;");
            if (b_tra == null || b_tra == undefined)
                b_tra = eval("b_goc").temp;
            // eval("b_goc." + b_ten + ".close();"); eval("b_goc." + b_ten + "=null;");
            b_damo = "";
            for (var i = 0; i < a_damo.length; i++) {
                if (a_damo[i] != b_ten) b_damo = kytu_Fs_them(b_damo, a_damo[i]);
            }
            b_goc.damo = b_damo;
            if (a_tso != null && b_tra != null && b_tra != "") {
                var a_s = b_tra.split(',');
                // if (Fb_MA_MA(b_damo, a_s[0]))
                {
                    if (eval("b_goc.P_KET_QUA") != null) {
                        eval("b_goc.focus();");
                        eval("b_goc.P_KET_QUA(a_s[1], a_tso);");
                    }
                }
                eval("b_goc." + b_ten + ".close();"); eval("b_goc." + b_ten + "=null;");
            }
        }
        else {
            for (var i = 0; i < a_damo.length; i++) {
                eval("b_goc." + a_damo[i] + ".close();"); eval("b_goc." + a_damo[i] + "=null;");
            }
        }
    }
    catch (err) { }
}
// Day tham so cho form khac
function form_P_DAY(b_ten, b_nhan, b_dtuong, a_tso) {
    try {
        var b_goc = form_F_GOC();
        var b_damo = b_goc.damo;
        if (b_damo == null || b_damo == undefined || b_damo == "") return;
        if (b_nhan == "") b_nhan = eval("b_goc." + b_ten + ".damo;");
        if (b_nhan == "" || b_nhan == null) return;
        var a_damo = b_damo.split(',');
        for (var i = 0; i < a_damo.length; i++) {
            if (a_damo[i] != b_ten && (b_nhan == "*" || b_nhan == a_damo[i])) {
                if (eval("b_goc." + a_damo[i]) != null) {
                    if (eval("b_goc." + a_damo[i] + ".P_KET_QUA") != null) eval("b_goc." + a_damo[i] + ".P_KET_QUA(b_dtuong, a_tso);");
                }
            }
        }
    }
    catch (err) { }
}